package com.infinite.olympiad.controller;

import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.infinite.olympiad.DO.CoreHrDO;
import com.infinite.olympiad.helper.CoreHrHelper;
import com.infinite.olympiad.manager.CoreHrManager;
import com.infinite.olympiad.vo.CoreHrVO;

/**
 * Servlet implementation class CoreHrController
 */
@WebServlet("/CoreHrController")
public class CoreHrController extends HttpServlet {

	private static final long serialVersionUID = 1L;

	private CoreHrManager coreHrManager = new CoreHrManager();

	public CoreHrController() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//No methods are calling here
	}


	/* 
	 * (non-Javadoc)
	 * This Servlet is used to add the employees 
	 * @see javax.servlet.http.HttpServlet#doPost(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 * 
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		try {
			//Getting the information from UI
			Date simpleDateFormat_doj = null;
			int empId=Integer.parseInt(request.getParameter("empId"));
			String empName=request.getParameter("empName");
			String gender=request.getParameter("gender");
			String mobile=request.getParameter("mobileNo");
			System.out.println("****** "+mobile);
			String project=request.getParameter("project");
			String designation=request.getParameter("designation");
			String location=request.getParameter("location");
			String email=request.getParameter("email");
			String manager=request.getParameter("manager");
			DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
			simpleDateFormat_doj = dateFormat.parse(request.getParameter("doj"));
			
			//Setting the Values to VO
			CoreHrVO coreHrVO = new CoreHrVO();
			coreHrVO.setEmployeeId(empId);
			coreHrVO.setEmployee_Name(empName);
			coreHrVO.setGender(gender);
			System.err.println("gender******controller"+gender);
			coreHrVO.setMobileNo(Long.parseLong(mobile));
			coreHrVO.setProjectName(project);
			coreHrVO.setDesignation(designation);
			coreHrVO.setLocation(location);
			coreHrVO.setEmail(email);
			coreHrVO.setRepoManager(manager);
			coreHrVO.setDoj(simpleDateFormat_doj);

			//Converting the values VO to DO
			CoreHrHelper CoreHrHelper = new CoreHrHelper();
			CoreHrDO coreHrEmployee_Info=CoreHrHelper.convertVotoDO(coreHrVO);
			
			//Calling the Manager 
			int value =coreHrManager.getCoreHrDetails(coreHrEmployee_Info);
			
			//Validating the data and posting success message to UI
			String message;
			if (value>=1) {
				message="Employee Added Successfully";
				request.setAttribute("pMessage",message);	
			} else {
				message="Something Went Wrong";
				request.setAttribute("pMessage",message);	
			}

			//For posting the message in UI
			
			RequestDispatcher rd=request.getRequestDispatcher("dashBoard.jsp");
			rd.include(request, response);

		} catch (ParseException e) {
			e.printStackTrace();
		}

	}	

}
