package com.infinite.olympiad.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.infinite.olympiad.DO.OlympiadHousesDO;
import com.infinite.olympiad.helper.CoreHrHelper;

/**
 * Servlet implementation class OlympiadDetailsController
 */
@WebServlet("/OlympiadDetailsController")
public class OlympiadDetailsController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public OlympiadDetailsController() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//Calling the do Post method 
		doPost(request,response);
	}

	/* 
	 * (non-Javadoc)
	 * This Servlet is used to get the all the details of olympiadHouses count per house. 
	 * @see javax.servlet.http.HttpServlet#doPost(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 * 
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		try{
			//Getting the details of the olympiad Houses overall count from getOlympiadDetails.
			CoreHrHelper coreHrHelper = new CoreHrHelper();
			List<OlympiadHousesDO> houseOverViewList = coreHrHelper.getOlympiadDetails();

			//Validating the list is empty or null
			if( (!houseOverViewList.isEmpty()) && ( !(houseOverViewList.size()==0) ) ){
				request.setAttribute("olympiadDetails",houseOverViewList);
				RequestDispatcher rd=request.getRequestDispatcher("olympiadOverview.jsp");
				rd.include(request, response);	
			}else{
				RequestDispatcher rd=request.getRequestDispatcher("OlympiadDetailsController");
				rd.include(request, response);	
			}
			
		}catch(NullPointerException nullPointerException){
			nullPointerException.printStackTrace();
		}catch (Exception exception) {
			exception.printStackTrace();
		}
	}

}
