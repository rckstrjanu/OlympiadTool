package com.infinite.olympiad.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.infinite.olympiad.DO.HrMain;
import com.infinite.olympiad.helper.CoreHrHelper;

/**
 * Servlet implementation class AddActiveEmployeesController
 */
@WebServlet("/AddActiveEmployeesController")
public class AddActiveEmployeesController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddActiveEmployeesController() {
        super();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try{
			// Getting the employeesList from getActiveEmployeesDetails from Helper
			response.setContentType("text/html");
			CoreHrHelper coreHrHelper = new CoreHrHelper();
			int empStatus = coreHrHelper.getEmployeesStatus();
			System.out.println("Employee Status::::::"+empStatus);
			String message;
			if(empStatus>=1){
				
				message = "Employees are assigned to respective Houses Successfully";
				request.setAttribute("message",message);	
				RequestDispatcher rd=request.getRequestDispatcher("OlympiadDetailsController");
				rd.include(request, response);

			}else{
				message = "Opps! Something went Wrong ";
				request.setAttribute("message",message);	
				RequestDispatcher rd=request.getRequestDispatcher("ActiveEmployeeDetails.jsp");
				rd.include(request, response);

			}
		}catch(NullPointerException nullPointerException){
			nullPointerException.printStackTrace();
		}catch (Exception exception) {
			exception.printStackTrace();
		}
	}

}
