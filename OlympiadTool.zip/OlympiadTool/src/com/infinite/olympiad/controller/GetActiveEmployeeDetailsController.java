package com.infinite.olympiad.controller;

import java.io.IOException;
import java.util.Iterator;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.infinite.olympiad.DO.EmployeeInformationDO;
import com.infinite.olympiad.DO.HrMain;
import com.infinite.olympiad.helper.CoreHrHelper;

/**
 * Servlet implementation class GetActiveEmployeeDetailsController
 */
@WebServlet("/GetActiveEmployeeDetailsController")
public class GetActiveEmployeeDetailsController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public GetActiveEmployeeDetailsController() {
        super();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		try{
			// Getting the employeesList from getActiveEmployeesDetails from Helper 
			CoreHrHelper coreHrHelper = new CoreHrHelper();
			List<HrMain> actEmpList = coreHrHelper.getActiveEmployeesDetails();
			
			// Validating the list is empty or not.
			if( (!actEmpList.isEmpty()) && ( !(actEmpList.size()==0) ) ){
				
				//If list is not empty  it will send the response to ActiveEmployeeDetails.jsp
				
				response.setContentType("text/html");
				request.setAttribute("houseEmployees",actEmpList);
				RequestDispatcher rd=request.getRequestDispatcher("ActiveEmployeeDetails.jsp");
				rd.include(request, response);	

			}else{
				
				// If the list is empty or null it will redirect to same page where it is calling.
				
				response.setContentType("text/html");
				String newJoineesMessage = " OOPS! No data";
				request.setAttribute("message",newJoineesMessage);	
				RequestDispatcher rd=request.getRequestDispatcher("NoDataFound.jsp");
				rd.include(request, response);	
			}
		}catch(NullPointerException nullPointerException){
			nullPointerException.printStackTrace();
		}catch (Exception exception) {
			exception.printStackTrace();
		}
		
	}

}
