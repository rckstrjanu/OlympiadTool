package com.infinite.olympiad.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.infinite.olympiad.DO.OlympiadHousesDO;
import com.infinite.olympiad.helper.CoreHrHelper;
import com.infinite.olympiad.manager.CoreHrManager;
import com.infinite.olympiad.vo.OlympiadHousesVO;

/**
 * Servlet implementation class AddNewHouseController
 */
@WebServlet("/AddNewHouseController")
public class AddNewHouseController extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public AddNewHouseController() {
        super();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try{
			//getting the values from UI
			String house_Name = request.getParameter("houseName");
			System.out.println("House_Name is::::"+house_Name);
			
			//Setting the values to VO
			OlympiadHousesVO olympiadHousesVO  = new OlympiadHousesVO();
			olympiadHousesVO.setHouseName(house_Name);
			
			//Converting VO to DO
			CoreHrHelper coreHrHelper = new CoreHrHelper();
			OlympiadHousesDO olympiadHousesDO = coreHrHelper.addNewHouse(olympiadHousesVO);
			
			//Calling the manager
			CoreHrManager coreHrManager = new CoreHrManager();
			int status = coreHrManager.addNewHouse(olympiadHousesDO);
			System.out.println("List Contains:::::"+status);
		}catch(NullPointerException nullPointerException){
			nullPointerException.printStackTrace();
		}catch (Exception exception) {
			exception.printStackTrace();
		}
	}

}
