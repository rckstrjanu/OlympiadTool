package com.infinite.olympiad.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.infinite.olympiad.DO.EmployeeInformationDO;
import com.infinite.olympiad.DO.OlympiadHousesDO;
import com.infinite.olympiad.helper.CoreHrHelper;
import com.infinite.olympiad.manager.CoreHrManager;
import com.infinite.olympiad.vo.EmployeeInformationVO;
import com.infinite.olympiad.vo.OlympiadHousesVO;

/**
 * Servlet implementation class EditEmployeeInfoByIdController
 */
@WebServlet("/EditEmployeeInfoByIdController")
public class EditEmployeeInfoByIdController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EditEmployeeInfoByIdController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		try{
			//getting the parameters from UI.
			int empId = Integer.parseInt(request.getParameter("id"));
			System.err.println("Requested Id is::::"+empId);
			//Setting the values to VO
			EmployeeInformationVO employeeInformationVO = new EmployeeInformationVO();
			employeeInformationVO.setEmpId(empId);

			//Converting the values from VO to DO
			CoreHrHelper CoreHrHelper = new CoreHrHelper();
			EmployeeInformationDO emp_info=CoreHrHelper.searchEmpDetailsById(employeeInformationVO);

			//Calling the Manager searchHouseDetailsById
			CoreHrManager coreHrManager = new CoreHrManager();
			List<EmployeeInformationDO> empByIdList =coreHrManager.searchEmpDetailsById(emp_info);
			System.err.println("List contains::::"+empByIdList.get(0));
			//Validating the list is empty or null.
			if(!empByIdList.isEmpty()&&(!empByIdList.equals(null))){
				//If the list is not null or not empty it will redirect to houseDetails.jsp
				System.out.println("Inside If");
				response.setContentType("text/html");
				request.setAttribute("empByIdList",empByIdList);
				RequestDispatcher rd=request.getRequestDispatcher("updateEmployeeById.jsp");
				System.out.println("After request dispatcher");
				rd.include(request, response);	

			}else{
				//If the list is empty or null it will send the response redirect to the same jsp.
				RequestDispatcher rd=request.getRequestDispatcher("OlympiadDetailsController");
				rd.include(request, response);	
			}

		}catch(Exception e){
			e.printStackTrace();
		}
	}

}
