package com.infinite.olympiad.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.infinite.olympiad.DO.EmployeeInformationDO;
import com.infinite.olympiad.DO.OlympiadHousesDO;
import com.infinite.olympiad.helper.CoreHrHelper;
import com.infinite.olympiad.manager.CoreHrManager;
import com.infinite.olympiad.vo.OlympiadHousesVO;

/**
 * Servlet implementation class HouseInfoByIdController
 */
@WebServlet("/HouseInfoByIdController")
public class HouseInfoByIdController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	public HouseInfoByIdController() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//Calling the do Post method 
		doPost(request,response);
	}

	/* 
	 * (non-Javadoc)
	 * This Servlet is used to get the all the details of employees with the respective id. 
	 * @see javax.servlet.http.HttpServlet#doPost(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 * 
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
			response.setContentType("text/html");
		try{
			//getting the parameters from UI.
			String houseName = request.getParameter("id");
			//Setting the values to VO
			OlympiadHousesVO  olympiadHousesVO = new OlympiadHousesVO();
			olympiadHousesVO.setHouseName(houseName);

			//Converting the values from VO to DO
			CoreHrHelper CoreHrHelper = new CoreHrHelper();
			OlympiadHousesDO house_info=CoreHrHelper.searchHouseDetailsById(olympiadHousesVO);

			//Calling the Manager searchHouseDetailsById
			CoreHrManager coreHrManager = new CoreHrManager();
			List<EmployeeInformationDO> olympiadHouseMemList =coreHrManager.searchHouseDetailsById(house_info);

			//Validating the list is empty or null.
			if(!olympiadHouseMemList.isEmpty()&&(!olympiadHouseMemList.equals(null))){
				//If the list is not null or not empty it will redirect to houseDetails.jsp
				request.setAttribute("houseDetails",olympiadHouseMemList);
				RequestDispatcher rd=request.getRequestDispatcher("houseDetails.jsp");
				rd.include(request, response);	

			}else{
				//If the list is empty or null it will send the response redirect to the same jsp.
				RequestDispatcher rd=request.getRequestDispatcher("OlympiadDetailsController");
				rd.include(request, response);	
			}

		}catch(Exception e){
			e.printStackTrace();
		}
	}


}
