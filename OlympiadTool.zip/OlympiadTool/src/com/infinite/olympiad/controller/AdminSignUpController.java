package com.infinite.olympiad.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.infinite.olympiad.DO.AdminSignUpDO;
import com.infinite.olympiad.helper.AdminSignUpHelper;
import com.infinite.olympiad.manager.AdminSignUpManager;
import com.infinite.olympiad.vo.AdminSignUpVO;

/**
 * Servlet implementation class AdminSignUpController
 */
@WebServlet("/AdminSignUpController")
public class AdminSignUpController extends HttpServlet {
	
	private static final long serialVersionUID = 1L;

	public AdminSignUpController() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	}

	/* 
	 * (non-Javadoc)
	 * This Servlet is used to sign up the user .
	 * @see javax.servlet.http.HttpServlet#doPost(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 * 
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		try{
			//Getting values from the UI
			int id=Integer.parseInt(request.getParameter("empId")); 
			String name = request.getParameter("empName");
			String email = request.getParameter("email");
			String password = request.getParameter("password");
			long mobile = Long.parseLong(request.getParameter("mobile"));
			
			//Assigning values to AdminSignUpVO
			AdminSignUpVO adminSignUpVO = new AdminSignUpVO();
			adminSignUpVO.setEmp_Id(id);
			adminSignUpVO.setEmp_Name(name);
			adminSignUpVO.setEmp_Email(email);
			adminSignUpVO.setPassword(password);
			adminSignUpVO.setMobile_No(mobile);

			//Converting VO to DO
			AdminSignUpHelper adminSignUpHelper = new AdminSignUpHelper();
			AdminSignUpDO  adminSignUpDO = adminSignUpHelper.registerAdmin(adminSignUpVO);
			
			//Calling the AdminSignUpManager
			AdminSignUpManager adminSignUpManager = new AdminSignUpManager();
			int value =adminSignUpManager.registerAdmin(adminSignUpDO);

			//Verifying the user
			String message;
			if (value>=1) {
				message="Employee registered Successfully";
			} else {
				message="Something Went Wrong";
			}

			//Sending the response to UI
			request.setAttribute("pMessage",message);	
			RequestDispatcher rd=request.getRequestDispatcher("AdminSignUp.jsp");
			rd.include(request, response);
			
		}catch(NullPointerException nullPointerException){
			nullPointerException.printStackTrace();
		}catch (Exception exception) {
			exception.printStackTrace();
		}
	}

}
