package com.infinite.olympiad.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.infinite.olympiad.DO.EmployeeInformationDO;
import com.infinite.olympiad.helper.CoreHrHelper;

/**
 * Servlet implementation class GetEmployeesController
 */
@WebServlet("/GetEmployeesController")
public class GetEmployeesController extends HttpServlet {
	private static final long serialVersionUID = 1L;


	public GetEmployeesController() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//Calling the do Post method 
		doPost(request, response);
	}

	/* 
	 * (non-Javadoc)
	 * This Servlet is used to get the all the details of employees. 
	 * @see javax.servlet.http.HttpServlet#doPost(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 * 
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		try{
			//Getting the employeesList from getEmployeesDetails from Helper 
			CoreHrHelper coreHrHelper = new CoreHrHelper();
			List<EmployeeInformationDO> housesmployeesList = coreHrHelper.getEmployeesDetails();
			
			//Validating the list is empty or not.
			if( (!housesmployeesList.isEmpty()) && ( !(housesmployeesList.size()==0) ) ){
				//If list is not empty  it will send the response to employeesDetails.jsp
				response.setContentType("text/html");
				request.setAttribute("houseEmployees",housesmployeesList);
				RequestDispatcher rd=request.getRequestDispatcher("employeesDetails.jsp");
				rd.include(request, response);	

			}else{
				//If the list is empty or null it will redirect to same page where it is calling.
				response.setContentType("text/html");
				RequestDispatcher rd=request.getRequestDispatcher("OlympiadDetailsController");
				rd.include(request, response);	

			}
		}catch(NullPointerException nullPointerException){
			nullPointerException.printStackTrace();
		}catch (Exception exception) {
			exception.printStackTrace();
		}
	}

}
