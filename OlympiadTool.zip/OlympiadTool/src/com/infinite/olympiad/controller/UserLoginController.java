package com.infinite.olympiad.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Iterator;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.infinite.olympiad.DO.LoginUserDO;
import com.infinite.olympiad.helper.UserLoginHelper;
import com.infinite.olympiad.manager.UserLoginManager;
import com.infinite.olympiad.vo.LoginUserVO;

/**
 * Servlet implementation class TransactionsController
 */
@WebServlet("/UserLoginController")
public class UserLoginController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public UserLoginController() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

	}

	/* 
	 * (non-Javadoc)
	 * This Servlet is used to login the user based on their email and password.
	 * @see javax.servlet.http.HttpServlet#doPost(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 * 
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		response.setContentType("text/html");  
		PrintWriter out=response.getWriter();
		try{
			String message=null;
			//Getting the parameters from UI
			String email = request.getParameter("userEmail");
			String password = request.getParameter("userPassword");

			//Setting the values to VO
			LoginUserVO loginUserVO = new LoginUserVO();
			loginUserVO.setEmail(email);
			loginUserVO.setPassword(password);

			//Converting VO to DO
			UserLoginHelper loginHelper = new UserLoginHelper();
			LoginUserDO loginUserDO = loginHelper.checkUserExist(loginUserVO);

			//Calling the manager userAutheticationCheck to check and validate the user based on the email and password 
			UserLoginManager loginManager=new UserLoginManager();
			List loginDetailsList=loginManager.userAutheticationCheck(loginUserDO);
			Iterator loginListIterator = loginDetailsList.iterator();

			//Iterating the object to get the Email, Username, Password.
			Object loginDetailsObject[] = null;
			while (loginListIterator.hasNext()) {
				loginDetailsObject = (Object[]) loginListIterator.next();
			}
			//Validating the User if user exits it will redirect to home page else it will throw error.
			if(!(loginDetailsObject==null) && loginDetailsObject[1].equals(email) && loginDetailsObject[2].equals(password))
			{
				String userName = (String) loginDetailsObject[0];
				out.print("Welcome, " + loginDetailsObject[0]);
				HttpSession session = request.getSession();
				session.setAttribute("name", loginDetailsObject[0]);
				session.setMaxInactiveInterval(10);
				RequestDispatcher rd = request.getRequestDispatcher("dashBoard.jsp");
				rd.include(request, response);
			}else{
				message="Sorry, username or password error!";
				request.setAttribute("pMessage",message);	
				RequestDispatcher rd=request.getRequestDispatcher("login.jsp");
				rd.include(request, response);
			}
		}catch(NullPointerException nullpointerException){
			nullpointerException.printStackTrace();
			System.err.println("NullPointer Exception::::"+nullpointerException.getMessage());
		}
	}
}
