package com.infinite.olympiad.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.infinite.olympiad.DO.EmployeeInformationDO;
import com.infinite.olympiad.helper.CoreHrHelper;
import com.infinite.olympiad.manager.CoreHrManager;
import com.infinite.olympiad.vo.EmployeeInformationVO;

/**
 * Servlet implementation class UpdateEmployeeInfoController
 */
@WebServlet("/UpdateEmployeeInfoController")
public class UpdateEmployeeInfoController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdateEmployeeInfoController() {
        super();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		try{
			
			
			String house_Name = request.getParameter("options");
			System.out.println("House Name is::::"+house_Name);
			int empId= Integer.parseInt(request.getParameter("empId"));
			System.err.println("Id of the click link is:::::"+empId);
			//Setting the values to VO
			EmployeeInformationVO employeeInformationVO = new EmployeeInformationVO();
			employeeInformationVO.setEmpId(empId);
			employeeInformationVO.setHouseName(house_Name);

			//Converting the values from VO to DO
			CoreHrHelper CoreHrHelper = new CoreHrHelper();
			EmployeeInformationDO update_Emp_info=CoreHrHelper.updateEmpDetailsById(employeeInformationVO);

			//Calling the Manager searchHouseDetailsById
			CoreHrManager coreHrManager = new CoreHrManager();
			List<EmployeeInformationDO> update_Emp_info_List =coreHrManager.updateEmpDetailsById(update_Emp_info);
			System.err.println("List contains::::"+update_Emp_info_List.get(0));
			//Validating the list is empty or null.
			if(!update_Emp_info_List.isEmpty()&&(!update_Emp_info_List.equals(null))){
				//If the list is not null or not empty it will redirect to houseDetails.jsp
				System.out.println("Inside If");
				response.setContentType("text/html");
				String successMessage="Employee Has been updated";
				request.setAttribute("updatedEmpList",successMessage);
				RequestDispatcher rd=request.getRequestDispatcher("OlympiadDetailsController");
				System.out.println("After request dispatcher");
				rd.include(request, response);	

			}else{
				//If the list is empty or null it will send the response redirect to the same jsp.
				RequestDispatcher rd=request.getRequestDispatcher("OlympiadDetailsController");
				rd.include(request, response);	
			}
		}catch(Exception e){
			e.printStackTrace();
		}
	}

}
