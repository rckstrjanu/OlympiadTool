package com.infinite.olympiad.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.infinite.olympiad.DO.TransactionDetailsDO;
import com.infinite.olympiad.helper.CoreHrHelper;

/**
 * Servlet implementation class TransactionsController
 */
@WebServlet("/TransactionsController")
public class TransactionsController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	public TransactionsController() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//Calling the do Post method 
		doPost(request, response);
	}

	/* 
	 * (non-Javadoc)
	 * This Servlet is used to get the transactions happened on the houses . 
	 * @see javax.servlet.http.HttpServlet#doPost(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 * 
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		List<TransactionDetailsDO> transactionsList = null;
		try{
			//Getting the transactions from getOlympiadTransactions
			CoreHrHelper coreHrHelper = new CoreHrHelper();
			transactionsList = coreHrHelper.getOlympiadTransactions();
			
			//Validating the list is empty or not if not it will fetch the list of transactions.
			if( (!transactionsList.isEmpty()) && ( !(transactionsList.size()==0) ) ){
				request.setAttribute("employeeTransactions",transactionsList);
				RequestDispatcher rd=request.getRequestDispatcher("transactions.jsp");
				rd.include(request, response);	
			}else{
				RequestDispatcher rd=request.getRequestDispatcher("NoDataFound.jsp");
				rd.include(request, response);	
			}
		}catch(NullPointerException nullPointerException){
			nullPointerException.printStackTrace();
		}catch (Exception exception) {
			exception.printStackTrace();
		}
	}

}
