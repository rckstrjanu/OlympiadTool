package com.infinite.olympiad.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.infinite.olympiad.DO.EmployeeInformationDO;
import com.infinite.olympiad.helper.CoreHrHelper;
import com.infinite.olympiad.manager.CoreHrManager;
import com.infinite.olympiad.vo.EmployeeInformationVO;

/**
 * Servlet implementation class DeleteEmployeeController
 */
@WebServlet("/DeleteEmployeeController")
public class DeleteEmployeeController extends HttpServlet {
	
	private static final long serialVersionUID = 1L;


	public DeleteEmployeeController() {
		super();

	}


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//Calling the do Post method 
		doPost(request, response);
	}

	/* 
	 * (non-Javadoc)
	 * This Servlet is used to delete the employees 
	 * @see javax.servlet.http.HttpServlet#doPost(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 * 
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		try{

			//Getting the values from UI
			String employeeId = request.getParameter("id");
			int empId = Integer.parseInt(employeeId);

			//validating the data employeeId.
			if(!employeeId.isEmpty() && !employeeId.equals(null)){

				//Setting the values to VO
				EmployeeInformationVO informationVO = new EmployeeInformationVO();
				informationVO.setEmpId(empId);

				//Converting the values from VO To DO.
				CoreHrHelper coreHrHelper = new CoreHrHelper();
				EmployeeInformationDO informationDO = coreHrHelper.deleteEmployeeInfoById(informationVO);

				//Calling the Manager deleteEmployeeInfoById
				CoreHrManager coreHrManager = new CoreHrManager();
				coreHrManager.deleteEmployeeInfoById(informationDO);
				
				//Sending the response to UI.
				response.setContentType("text/html");
				RequestDispatcher rd=request.getRequestDispatcher("GetEmployeesController");
				rd.include(request, response);

			}
		}catch(NullPointerException nullPointerException){
			nullPointerException.printStackTrace();
		}catch (Exception exception) {
			exception.printStackTrace();
		}
	}

}
