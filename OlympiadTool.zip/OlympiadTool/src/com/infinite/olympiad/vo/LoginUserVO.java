package com.infinite.olympiad.vo;

public class LoginUserVO {

	private String email;
	private String password;
	
	//Setters and Getters
	
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	
	
}
