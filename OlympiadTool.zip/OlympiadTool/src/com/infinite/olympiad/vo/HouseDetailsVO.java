/**
 * 
 */
package com.infinite.olympiad.vo;

import java.util.Date;

/**
 * @author nagamr
 *
 */
public class HouseDetailsVO {

	private String houseName;
	private Date houseEntryDate;	
	private String sponsors;
	private String houseExitDate;
	private String houseCaptain;
	
	
	public String getHouseName() {
		return houseName;
	}
	public void setHouseName(String houseName) {
		this.houseName = houseName;
	}
	public Date getHouseEntryDate() {
		return houseEntryDate;
	}
	public void setHouseEntryDate(Date houseEntryDate) {
		this.houseEntryDate = houseEntryDate;
	}
	public String getSponsors() {
		return sponsors;
	}
	public void setSponsors(String sponsors) {
		this.sponsors = sponsors;
	}
	public String getHouseExitDate() {
		return houseExitDate;
	}
	public void setHouseExitDate(String houseExitDate) {
		this.houseExitDate = houseExitDate;
	}
	public String getHouseCaptain() {
		return houseCaptain;
	}
	public void setHouseCaptain(String houseCaptain) {
		this.houseCaptain = houseCaptain;
	}
	
}
