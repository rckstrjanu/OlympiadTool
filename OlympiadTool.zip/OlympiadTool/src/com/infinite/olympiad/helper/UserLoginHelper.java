package com.infinite.olympiad.helper;

import com.infinite.olympiad.DO.LoginUserDO;
import com.infinite.olympiad.vo.LoginUserVO;

public class UserLoginHelper {

	private LoginUserDO  loginUserDO = new LoginUserDO();

	/**
	 * This method is used to check the user exist or not .
	 * @param loginUserVO
	 * @return loginUserDO
	 */
	public LoginUserDO checkUserExist(LoginUserVO loginUserVO){

		try{

			if(!loginUserVO.equals(null) && (!loginUserVO.equals("")) ){	

				loginUserDO.setEmail(loginUserVO.getEmail());
				loginUserDO.setPassword(loginUserVO.getPassword());

			}else{
				System.err.println("Null pointer Exception in checkUserExist");
			}
		}catch(NullPointerException nullPointerException){
			nullPointerException.printStackTrace();
			System.err.println("Exception in checkUserExist in UserLoginHelper :::::"+nullPointerException.getMessage());
		}catch (Exception exception) {
			exception.printStackTrace();
		}
		return loginUserDO;


	}
}
