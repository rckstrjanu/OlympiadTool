package com.infinite.olympiad.helper;

import java.util.List;

import com.infinite.olympiad.DO.CoreHrDO;
import com.infinite.olympiad.DO.EmployeeInformationDO;
import com.infinite.olympiad.DO.HrMain;
import com.infinite.olympiad.DO.OlympiadHousesDO;
import com.infinite.olympiad.DO.TransactionDetailsDO;
import com.infinite.olympiad.manager.CoreHrManager;
import com.infinite.olympiad.vo.CoreHrVO;
import com.infinite.olympiad.vo.EmployeeInformationVO;
import com.infinite.olympiad.vo.OlympiadHousesVO;

public class CoreHrHelper {

	CoreHrDO coreHrDO = new CoreHrDO();

	OlympiadHousesDO olympiadHousesDO = new OlympiadHousesDO();

	CoreHrManager coreHrManager = new CoreHrManager();

	EmployeeInformationDO informationDO = new EmployeeInformationDO();

	/**
	 * This method converts the vo to domain object
	 * 
	 * @param coreHrVO
	 * @return coreHrVO
	 * 
	 */
	public CoreHrDO convertVotoDO(CoreHrVO coreHrVO) {

		System.out.println("Inside convertVotoDO");
		coreHrDO.setEmployeeId(coreHrVO.getEmployeeId());
		coreHrDO.setEmployee_Name(coreHrVO.getEmployee_Name());
		coreHrDO.setGender(coreHrVO.getGender());
		coreHrDO.setMobileNo(coreHrVO.getMobileNo());
		coreHrDO.setProjectName(coreHrVO.getProjectName());
		coreHrDO.setDesignation(coreHrVO.getDesignation());
		coreHrDO.setLocation(coreHrVO.getLocation());
		coreHrDO.setEmail(coreHrVO.getEmail());
		coreHrDO.setRepoManager(coreHrVO.getRepoManager());
		coreHrDO.setDoj(coreHrVO.getDoj());

		return coreHrDO;
	}

	/**
	 * This method is used to get the olympiadHouse overview Details
	 * @return houseOverViewList
	 */
	public List getOlympiadDetails() {

		List houseOverViewList = coreHrManager.getOlympiadDetails();

		return houseOverViewList;
	}

	/**
	 * This method is used to search the employees based on the ID.
	 * @param olympiadHousesVO
	 * @return olympiadHousesDO
	 */
	public OlympiadHousesDO searchHouseDetailsById(OlympiadHousesVO olympiadHousesVO) {
		olympiadHousesDO.setHouseName(olympiadHousesVO.getHouseName());
		return olympiadHousesDO;
	}

	/**
	 * This method is used to delete the employee based on the ID.
	 * @param informationVO
	 * @return informationDO
	 */
	public EmployeeInformationDO deleteEmployeeInfoById(EmployeeInformationVO informationVO){
		informationDO.setEmpId(informationVO.getEmpId());
		return informationDO;
	}

	/**
	 * This method is used to get the employees assigned to particular house.
	 * @return employeesList
	 */
	public List<EmployeeInformationDO> getEmployeesDetails() {
		List employeesList = coreHrManager.getEmployeesDetails();
		return employeesList;
	}

	/**
	 * This method is used to get the transaction happen on the olympiad tables
	 * @return transactionsList
	 */
	public List<TransactionDetailsDO> getOlympiadTransactions() {
		List<TransactionDetailsDO> transactionsList = coreHrManager.getOlympiadTransactions();
		return transactionsList;
	}

	/**
	 * To get the list of employees whose status is active.
	 * @return actEmpList
	 */
	public List<HrMain> getActiveEmployeesDetails() {
		List actEmpList = coreHrManager.getActiveEmployeesDetails();
		return actEmpList;
	}

	/**
	 * TO get the employee status wheather ACTIVE or EXIT.
	 * @return empStatus
	 */
	public int getEmployeesStatus() {
		int empStatus = coreHrManager.getEmployeesStatus();
		return empStatus;
	}

	/**
	 * To search the employees based on the ID.
	 * @param employeeInformationVO
	 * @return informationDO
	 */
	public EmployeeInformationDO searchEmpDetailsById(EmployeeInformationVO employeeInformationVO) {
		informationDO.setEmpId(employeeInformationVO.getEmpId());
		return informationDO ;
	}

	/**
	 * To update the Employees based on ID.
	 * @param employeeInformationVO
	 * @return informationDO
	 */
	public EmployeeInformationDO updateEmpDetailsById(EmployeeInformationVO employeeInformationVO) {
		informationDO.setEmpId(employeeInformationVO.getEmpId());
		informationDO.setHouseName(employeeInformationVO.getHouseName());
		return informationDO ;
	}

	public OlympiadHousesDO addNewHouse(OlympiadHousesVO olympiadHousesVO) {
		olympiadHousesDO.setHouseName(olympiadHousesVO.getHouseName());
		return olympiadHousesDO;
	}
}
