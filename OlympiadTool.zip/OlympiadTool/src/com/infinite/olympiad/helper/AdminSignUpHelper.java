package com.infinite.olympiad.helper;

import java.util.Date;

import com.infinite.olympiad.DO.AdminSignUpDO;
import com.infinite.olympiad.vo.AdminSignUpVO;

public class AdminSignUpHelper {

	private AdminSignUpDO adminSignUpDO = new AdminSignUpDO();
	
	public AdminSignUpDO registerAdmin(AdminSignUpVO adminSignUpvO){
		
		try{
			
		adminSignUpDO.setEmp_Id(adminSignUpvO.getEmp_Id());
		adminSignUpDO.setEmp_Name(adminSignUpvO.getEmp_Name());
		adminSignUpDO.setEmp_Email(adminSignUpvO.getEmp_Email());
		adminSignUpDO.setPassword(adminSignUpvO.getPassword());
		adminSignUpDO.setMobile_No(adminSignUpvO.getMobile_No());
		adminSignUpDO.setRegisteredDate(new Date());
		
		}catch(NullPointerException exception){
			exception.printStackTrace();
			System.err.println("Exception in registerAdmin::::::"+exception.getMessage());
		}
		return adminSignUpDO;
		
	}
}
