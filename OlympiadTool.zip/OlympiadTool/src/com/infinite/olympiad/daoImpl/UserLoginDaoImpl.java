package com.infinite.olympiad.daoImpl;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.infinite.olympiad.DO.LoginUserDO;
import com.infinite.olympiad.dao.UserLoginDAO;
import com.infinite.olympiad.util.HibernateUtil;


/*
 * UserLoginDaoImpl implements UserLoginDAO
 */
public class UserLoginDaoImpl implements UserLoginDAO {
	
	SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
	Session session = sessionFactory.openSession();
	Transaction transaction = session.beginTransaction();
	
	
	/**
	 * This method is used to check the user based on the email, password.
	 * @return loginDetailsList
	 */
	public List userAutheticationCheckData(LoginUserDO loginUserDO) {
		
		List loginDetailsList=null;
		
		String email = loginUserDO.getEmail();
		String password = loginUserDO.getPassword();
		String userAutheticationquery="select Employee_Name,Email,Password from admin where Email=:Email and Password=:Password";
		try
		{
			
		SQLQuery query=session.createSQLQuery(userAutheticationquery);
		         query.setParameter("Email",email);
		         query.setParameter("Password", password);
		         
		         loginDetailsList= query.list();
		}catch (HibernateException h) {
			h.printStackTrace();
			System.err.println(" UserLoginDaoImpl in side  userAutheticationCheckData exception ::::: HibernateException"
							+ h.getMessage());
		} catch (NullPointerException nullPointerException) {
			nullPointerException.printStackTrace();
			System.err.println(" UserLoginDaoImpl in side  userAutheticationCheckData exception ::::: Nullpointer Exception"
							+ nullPointerException.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
			System.err.println(" UserLoginDaoImpl in side  userAutheticationCheckData exception ::::: Exception"
							+ e.getMessage());
		} finally {
			System.err.println(" CoreHrDAOImpl Inside Finnally method:::::::");
		}
		return loginDetailsList;
	}

}
