package com.infinite.olympiad.daoImpl;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Date;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.infinite.olympiad.dao.EmployeeInformationDAO;
import com.infinite.olympiad.util.HibernateUtil;
import com.infinite.olympiad.vo.EmployeeInformationVO;
import com.infinite.olympiad.vo.OlympiadHousesVO;

public class EmployeeInformationDAOImpl implements EmployeeInformationDAO {

	public static void main(String[] args) {
	}

	//This method is used to add the employees information
	@Override
	public int addEmployeeInformation(EmployeeInformationVO employeeInformation) {
		SessionFactory sessionFactory=HibernateUtil.getSessionFactory();
		Session session =sessionFactory.openSession();
		Transaction transaction =session.beginTransaction();
		int id=(Integer) session.save(employeeInformation);
		transaction.commit();
		updateCount(employeeInformation);
		return id;
	}

	//This method is used to check the olympiad houses information
	@Override
	public void checkOlympiadHouseInfo() {
		try{
			System.out.println("Inside the checkOlympiadHouseInfo()");
			OlympiadHousesVO  spartanHouse = new OlympiadHousesVO("Spartans", 0, 0, 0, new Date("02/05/2014"),null);
			OlympiadHousesVO  suryavanshHouse = new OlympiadHousesVO("Suryavansh", 0, 0, 0, new Date("02/05/2014"),null);
			OlympiadHousesVO  aztechsHouse = new OlympiadHousesVO("Aztechs", 0, 0, 0, new Date("02/05/2014"),null);
			OlympiadHousesVO  akkadiansHouse = new OlympiadHousesVO("Akkadians", 0, 0, 0, new Date("02/05/2014"),null);
			OlympiadHousesVO  aryansHouse = new OlympiadHousesVO("Aryans", 0, 0, 0, new Date("02/05/2014"),null);
			OlympiadHousesVO  mouryasHouse = new OlympiadHousesVO("Mouryas", 0, 0, 0, new Date("02/05/2014"),null);
			SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
			Session session = sessionFactory.openSession();
			Transaction transaction = session.beginTransaction();
			Query checkDataExists = session.createQuery("FROM OlympiadHouses");
			List<EmployeeInformationVO> list = checkDataExists.list();

			if(list.isEmpty()){
				System.out.println("Inside the if loop in checkOlympiadHouseInfo()");
				session.save(spartanHouse);
				session.save(suryavanshHouse);
				session.save(aztechsHouse);
				session.save(akkadiansHouse);
				session.save(aryansHouse);
				session.save(mouryasHouse);
			}else{
				System.out.println("Records are already exists.");
			}
			transaction.commit();
			System.out.println("After checkOlympiadHouseInfo()");
		}catch(NullPointerException nullpointerException){
			nullpointerException.printStackTrace();
			System.out.println("Null pointer exception in checkOlympiadHouseInfo()"+nullpointerException.getMessage());
		}
	}

	//This method is used to update the olympiadHouses COUNT table
	public String updateCount(EmployeeInformationVO employeeInformation) {
		checkOlympiadHouseInfo();
		String count_Query = null;
		String grandTotalQuery = null;
		Query totalCountQuery = null;
		Session session = null;
		Transaction transaction = null;
		try {
			String house_Name = employeeInformation.getHouseName();

			String gender = employeeInformation.getGender();

			//String houseAllocatedDate= employeeInformation.getHouseAllocatedDate();
			Date lastAddedDate =employeeInformation.getLastUpdatedDate();

			SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
			session = sessionFactory.openSession();
			transaction = session.beginTransaction();

			count_Query = "SELECT COUNT(HOUSE_NAME) FROM EMPLOYEE_INFO WHERE HOUSE_NAME=:HOUSE_NAME AND  GENDER=:GENDER ";
			Query countQuery = session.createSQLQuery(count_Query);
			countQuery.setParameter("HOUSE_NAME", house_Name);
			countQuery.setParameter("GENDER", gender);
			BigInteger convertedValue = (BigInteger) countQuery.uniqueResult();
			int returnValue = convertedValue.intValue();

			//For updating the no of males in each house
			if (gender.equalsIgnoreCase("Male")) {

				String updateQuery = "UPDATE HOUSES_OVERVIEW SET  NO_OF_MALES=:NO_OF_MALES , LAST_UPDATED_DATE=:LAST_UPDATED_DATE WHERE HOUSE_NAME=:HOUSE_NAME";
				Query updateMaleQuery = session.createSQLQuery(updateQuery);
				updateMaleQuery.setParameter("NO_OF_MALES",returnValue);
				updateMaleQuery.setParameter("HOUSE_NAME",house_Name);
				//updateMaleQuery.setParameter("CREATION_DATE",houseAllocatedDate);
				updateMaleQuery.setParameter("LAST_UPDATED_DATE",lastAddedDate);
				updateMaleQuery.executeUpdate();

			} else if (gender.equalsIgnoreCase("Female")) {
				//For updating the no of females in each house

				String updateQuery = "UPDATE HOUSES_OVERVIEW SET  NO_OF_FEMALES=:NO_OF_FEMALES, LAST_UPDATED_DATE=:LAST_UPDATED_DATE WHERE HOUSE_NAME=:HOUSE_NAME";
				Query updateFemaleQuery = session.createSQLQuery(updateQuery);
				updateFemaleQuery.setParameter("NO_OF_FEMALES", returnValue);
				updateFemaleQuery.setParameter("HOUSE_NAME", house_Name);
				//updateFemaleQuery.setParameter("CREATION_DATE", houseAllocatedDate);
				updateFemaleQuery.setParameter("LAST_UPDATED_DATE", lastAddedDate);
				updateFemaleQuery.executeUpdate();

			} else {

				System.err.println("Something Wrong");

			}
			//for updating the sum of the males and females
			grandTotalQuery = "SELECT (SUM(NO_OF_MALES)+SUM(NO_OF_FEMALES))  FROM HOUSES_OVERVIEW WHERE HOUSE_NAME=:HOUSE_NAME";
			if(!(grandTotalQuery==null)){
				totalCountQuery = session.createSQLQuery(grandTotalQuery);
				totalCountQuery.setParameter("HOUSE_NAME", house_Name);
			}
			BigDecimal convertedValue1 = (BigDecimal) totalCountQuery.uniqueResult();
			int returnValue1 = convertedValue1.intValue();
			if(!grandTotalQuery.isEmpty()){
				String updateQuery = "UPDATE HOUSES_OVERVIEW SET  TOTAL=:TOTAL WHERE HOUSE_NAME=:HOUSE_NAME";
				Query updateGrandTotalQuery = session.createSQLQuery(updateQuery);
				updateGrandTotalQuery.setParameter("TOTAL", returnValue1);
				updateGrandTotalQuery.setParameter("HOUSE_NAME", house_Name);
				updateGrandTotalQuery.executeUpdate();
			}
		} catch (HibernateException h) {
			h.printStackTrace();
			System.err.println(" EmployeeInformationDAOImpl in side  updateCount exception ::::: HibernateException"
					+ h.getMessage());
		} catch (NullPointerException nullPointerException) {
			nullPointerException.printStackTrace();
			System.err.println(" EmployeeInformationDAOImpl in side  updateCount exception ::::: Nullpointer Exception"
					+ nullPointerException.getMessage());
		}catch (Exception e) {
			e.printStackTrace();
			System.err.println(" EmployeeInformationDAOImpl in side  updateCount exception ::::: Exception"
					+ e.getMessage());
		}finally {
			session.flush();
			transaction.commit();
			System.err.println(" EmployeeInformationDAOImpl Inside Finnally method:::::::");
		}
		return "success";
	}

	//this method used to get the all the employees information
	@Override
	public List<EmployeeInformationVO> getEmployeesInfo() {
		SessionFactory sessionFactory=HibernateUtil.getSessionFactory();
		Session session =sessionFactory.openSession();
		Query query =session.createQuery("FROM EmployeeInformation");
		return query.list();
	}

	//This method is used to get the employee information by Id
	@Override
	public EmployeeInformationVO getEmployeesInfoById(int id) {
		SessionFactory sessionFactory=HibernateUtil.getSessionFactory();
		Session session =sessionFactory.openSession();
		EmployeeInformationVO empInfo =(EmployeeInformationVO) session.get(EmployeeInformationVO.class,id);
		System.out.println("empInfo:::::"+empInfo);
		return empInfo;
	}


}
