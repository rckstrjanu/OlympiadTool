package com.infinite.olympiad.daoImpl;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.infinite.olympiad.dao.HouseDetailsDAO;
import com.infinite.olympiad.util.HibernateUtil;
import com.infinite.olympiad.vo.HouseDetailsVO;

public class HouseDetailsDAOImpl implements HouseDetailsDAO {

	/**
	 * Adding house details
	 * 
	 * @param houseDetails
	 * @return id
	 */
	@Override
	public int addhouseDetails(HouseDetailsVO houseDetails) {

		SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
		Session session = sessionFactory.openSession();
		Transaction transaction = session.beginTransaction();
		int id = (Integer) session.save(houseDetails);
		transaction.commit();
		return id;
	}

}
