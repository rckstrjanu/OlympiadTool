package com.infinite.olympiad.daoImpl;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.infinite.olympiad.DO.AdminSignUpDO;
import com.infinite.olympiad.dao.AdminSignUpDAO;
import com.infinite.olympiad.util.HibernateUtil;

/**
 * Class AdminSignUPDAOImpl implements AdminSignUpDAO
 *
 */
public class AdminSignUPDAOImpl implements AdminSignUpDAO {

	/**
	 * This method is used to register the admin.
	 * @return id
	 */
	@Override
	public int registerAdmin(AdminSignUpDO adminSignUpDO) {
		int id = 0;
		try{
		SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
		Session session = sessionFactory.openSession();
		Transaction transaction = session.beginTransaction();
		id = (Integer) session.save(adminSignUpDO);
		transaction.commit();
		session.close();
		}catch(NullPointerException nullPointerException){
			nullPointerException.printStackTrace();
		}catch(HibernateException hibernateException){
			hibernateException.printStackTrace();
		}
		return id;
	}

}
