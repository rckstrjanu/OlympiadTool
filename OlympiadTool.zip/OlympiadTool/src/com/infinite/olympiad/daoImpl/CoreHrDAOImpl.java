package com.infinite.olympiad.daoImpl;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Hibernate;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.infinite.olympiad.DO.CoreHrDO;
import com.infinite.olympiad.DO.EmployeeInformationDO;
import com.infinite.olympiad.DO.HrMain;
import com.infinite.olympiad.DO.OlympiadHousesDO;
import com.infinite.olympiad.DO.TransactionDetailsDO;
import com.infinite.olympiad.dao.CoreHrDAO;
import com.infinite.olympiad.util.HibernateUtil;
import com.infinite.olympiad.vo.EmployeeInformationVO;

/**
 * class CoreHrDAOImpl implements CoreHrDAO
 *
 */
@SuppressWarnings({"rawtypes","unchecked"})
public class CoreHrDAOImpl implements CoreHrDAO {

	//global variables
	private EmployeeInformationVO information = new EmployeeInformationVO();
	
	
	public static void main(String[] args) {
		CoreHrDAOImpl coreHrDAOImpl = new CoreHrDAOImpl();
		EmployeeInformationDO informationDO = new EmployeeInformationDO();
		//coreHrDAOImpl.updateEmpDetailsById(informationDO);
		//coreHrDAOImpl.getOlympiadTransactions();
		coreHrDAOImpl.getOlympiadDetails();
	}
	

	/** 
	 * This method is used to store the employee information in coreHr table.
	 * @param coreHr
	 * @return id
	 * 
	 */

	@Override
	public int addCoreHrInfo(CoreHrDO coreHrEmployee_Info) {
		int id = 0;
		try{
			SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
			Session session = sessionFactory.openSession();
			Transaction transaction = session.beginTransaction();
			id = (Integer) session.save(coreHrEmployee_Info);
			transaction.commit();
			getCountOfEmployeeInfo(coreHrEmployee_Info);
			session.close();
		}catch(NullPointerException nullPointerException){
			nullPointerException.printStackTrace();
		}catch (HibernateException hibernateException) {
			hibernateException.printStackTrace();
		}catch (Exception exception) {
			exception.printStackTrace();
		}
		return id;
	}

	/** 
	 * This method is used to get the COUNT of employees 
	 * depending on the gender FROM HOUSES_OVERVIEW.
	 * @param coreHr
	 * @return success
	 * 
	 */
	public String getCountOfEmployeeInfo(CoreHrDO coreHrEmployee_Info) {
		checkOlympiadHouseInfo();
		SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
		Session session = sessionFactory.openSession();
		Transaction transaction = session.beginTransaction();
		try {
			String gender = coreHrEmployee_Info.getGender();
			Iterator it = null;

			if (gender.equalsIgnoreCase("Male")) {
				String maleMinCount = "SELECT HOUSE_NAME,NO_OF_MALES FROM HOUSES_OVERVIEW WHERE NO_OF_MALES=(SELECT MIN(NO_OF_MALES) FROM HOUSES_OVERVIEW)";
				Query query = session.createSQLQuery(maleMinCount)
						.addScalar("HOUSE_NAME", Hibernate.STRING)
						.addScalar("NO_OF_MALES", Hibernate.INTEGER);
				List listOfMales = query.list();
				it = listOfMales.iterator();

				Object obj[] = null;
				while (it.hasNext()) {
					obj = (Object[]) it.next();
				}
				if (obj.length == 1) {
					String house_Name = (String) obj[0];
					setHouse(coreHrEmployee_Info, house_Name);
				} else {
					Object minDateObjectMale[] = null;
					String minDateMale = " SELECT HOUSE_NAME,NO_OF_MALES,LAST_UPDATED_DATE FROM  HOUSES_OVERVIEW ORDER BY  NO_OF_MALES,LAST_UPDATED_DATE LIMIT 1";
					Query minDateQueryForMale = session
							.createSQLQuery(minDateMale)
							.addScalar("HOUSE_NAME", Hibernate.STRING)
							.addScalar("LAST_UPDATED_DATE", Hibernate.DATE);
					List minDatesList = minDateQueryForMale.list();
					Iterator minDateIterator = minDatesList.iterator();
					while (minDateIterator.hasNext()) {
						minDateObjectMale = (Object[]) minDateIterator.next();
						System.err.print(minDateObjectMale[0] + "---Male-----" + minDateObjectMale[1]);
					}
					if (minDateObjectMale.length == 2) {

						String house_Name = (String) minDateObjectMale[0];
						setHouse(coreHrEmployee_Info, house_Name);

					} else {

						String house_Name = null;
						getHouseId(coreHrEmployee_Info, house_Name);

					}
				}

			} else if (gender.equalsIgnoreCase("Female")) {

				String femaleMinCount = "SELECT HOUSE_NAME,NO_OF_FEMALES FROM HOUSES_OVERVIEW WHERE NO_OF_FEMALES=(SELECT MIN(NO_OF_FEMALES) FROM HOUSES_OVERVIEW)";
				Query query = session.createSQLQuery(femaleMinCount)
						.addScalar("HOUSE_NAME", Hibernate.STRING)
						.addScalar("NO_OF_FEMALES", Hibernate.INTEGER);
				List listOfFemales = query.list();
				it = listOfFemales.iterator();

				Object obj[] = null;
				while (it.hasNext()) {
					obj = (Object[]) it.next();
					System.err.println("Inside if condition for female 1 object"+obj[0]+"::::::"+obj[1]);
				}
				if (obj.length == 1) {

					String house_Name = (String) obj[0];
					System.err.println("Inside if condition for female 1 object"+obj[0]+"::::::"+obj[1]);
					setHouse(coreHrEmployee_Info, house_Name);

				} else {

					String minDateFemale = "SELECT HOUSE_NAME,NO_OF_FEMALES,LAST_UPDATED_DATE FROM  HOUSES_OVERVIEW ORDER BY  NO_OF_FEMALES,LAST_UPDATED_DATE LIMIT 1";
					Query minDateQueryForFemale = session.createSQLQuery(minDateFemale)
							.addScalar("HOUSE_NAME", Hibernate.STRING)
							.addScalar("LAST_UPDATED_DATE", Hibernate.DATE);
					List minDatesList = minDateQueryForFemale.list();
					Iterator minDateFemaleIterator = minDatesList.iterator();
					Object minDateObjectFemale[] = null;

					while (minDateFemaleIterator.hasNext()) {

						minDateObjectFemale = (Object[]) minDateFemaleIterator.next();
						System.err.print(minDateObjectFemale[0] + "---Female-----" + minDateObjectFemale[1]);
					}
					System.err.println("length::::::::::"+minDateObjectFemale.length);
					if (minDateObjectFemale.length == 2) {

						String house_Name = (String) minDateObjectFemale[0];
						setHouse(coreHrEmployee_Info, house_Name);

					} else {

						String house_Name = null;
						getHouseId(coreHrEmployee_Info, house_Name);

					}
				}
			}

		} catch (HibernateException h) {
			h.printStackTrace();
			System.err.println(" CoreHrDAOImpl in side  getCountOfEmployeeInfo exception ::::: HibernateException"
					+ h.getMessage());
		} catch (NullPointerException nullPointerException) {
			nullPointerException.printStackTrace();
			System.err.println(" CoreHrDAOImpl in side  getCountOfEmployeeInfo exception ::::: Nullpointer Exception"
					+ nullPointerException.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
			System.err.println(" CoreHrDAOImpl in side  getCountOfEmployeeInfo exception ::::: Exception"
					+ e.getMessage());
		} finally {
			session.flush();
			transaction.commit();
			System.err.println(" CoreHrDAOImpl Inside Finnally method:::::::");
		}
		return "Success";
	}

	/** 
	 * This method is used to set the House for employees 
	 * depending on the COUNT of gender and date and House_Idfrom HOUSES_OVERVIEW.
	 * @param coreHr
	 * @return void
	 * 
	 */

	public void getHouseId(CoreHrDO coreHrEmployee_Info, String house_Name) {
		try{
			SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
			Session session = sessionFactory.openSession();
			String gender = coreHrEmployee_Info.getGender();

			if (gender.equalsIgnoreCase("Male")) {

				Object minDateObjectMale[] = null;
				String minDateMale = "SELECT HOUSE_ID,HOUSE_NAME FROM HOUSES_OVERVIEW WHERE NO_OF_MALES=(SELECT MIN(NO_OF_MALES) FROM HOUSES_OVERVIEW) ORDER BY HOUSE_ID LIMIT 1";
				Query minDateQueryForFemale = session.createSQLQuery(minDateMale)
						.addScalar("HOUSE_ID", Hibernate.INTEGER)
						.addScalar("HOUSE_NAME", Hibernate.STRING);
				List minDatesList = minDateQueryForFemale.list();
				Iterator minDateFemaleIterator = minDatesList.iterator();

				minDateObjectMale = (Object[]) minDateFemaleIterator.next();
				house_Name = (String) minDateObjectMale[1];
				setHouse(coreHrEmployee_Info, house_Name);

			} else if (gender.equalsIgnoreCase("Female")) {

				String minDateMale = "SELECT HOUSE_ID,HOUSE_NAME FROM HOUSES_OVERVIEW WHERE NO_OF_FEMALES=(SELECT MIN(NO_OF_FEMALES) FROM HOUSES_OVERVIEW) ORDER BY HOUSE_ID LIMIT 1";
				Query minDateQueryForFemale = session.createSQLQuery(minDateMale)
						.addScalar("HOUSE_ID", Hibernate.INTEGER)
						.addScalar("HOUSE_NAME", Hibernate.STRING);
				List minDatesList = minDateQueryForFemale.list();
				Iterator minDateFemaleIterator = minDatesList.iterator();
				Object minDateObjectFemale[] = null;
				minDateObjectFemale = (Object[]) minDateFemaleIterator.next();
				house_Name = (String) minDateObjectFemale[1];
				setHouse(coreHrEmployee_Info, house_Name);

			}
		}catch(NullPointerException nullPointerException){
			nullPointerException.printStackTrace();
		}catch (HibernateException hibernateException) {
			hibernateException.printStackTrace();
		}catch (Exception exception) {
			exception.printStackTrace();
		}
	}

	/** 
	 * This method is used to set the House for employees 
	 * FROM HOUSES_OVERVIEW.
	 * @param coreHr
	 * @return success
	 * 
	 */
	public void setHouse(CoreHrDO coreHrEmployee_Info, String house_Name) {

		try{
			SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
			Session session = sessionFactory.openSession();
			Transaction transaction = session.beginTransaction();

			EmployeeInformationDO employeeInformation = new EmployeeInformationDO();

			employeeInformation.setEmpId(coreHrEmployee_Info.getEmployeeId());
			employeeInformation.setEmpName(coreHrEmployee_Info.getEmployee_Name());
			employeeInformation.setHouseName(house_Name);
			employeeInformation.setGender(coreHrEmployee_Info.getGender());
			employeeInformation.setHouseAllocatedDate(coreHrEmployee_Info.getDoj());

			Date date = new Date();
			employeeInformation.setLastUpdatedDate(date);
			session.save(employeeInformation);
			transaction.commit();
			updateCount(coreHrEmployee_Info, house_Name);
			session.close();
		}catch (NullPointerException nullPointerException) {
			nullPointerException.printStackTrace();
		}catch (HibernateException hibernateException) {
			hibernateException.printStackTrace();
		}catch (Exception exception) {
			exception.printStackTrace();
		}

	}

	/** 
	 * This method is used to initialize the default values for HOUSES_OVERVIEW.
	 * @param none
	 * @return void
	 * 
	 */
	public void checkOlympiadHouseInfo() {
		try {
			String date = "02/05/2014";
			DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
			Date newDate = dateFormat.parse(date);
			System.out.println("Inside the checkOlympiadHouseInfo()");
			OlympiadHousesDO spartanHouse = new OlympiadHousesDO("Spartans", 0, 0,
					0, newDate, null);
			OlympiadHousesDO suryavanshHouse = new OlympiadHousesDO("Suryavansh",
					0, 0, 0, newDate, null);
			OlympiadHousesDO aztechsHouse = new OlympiadHousesDO("Aztechs", 0, 0,
					0, newDate, null);
			OlympiadHousesDO akkadiansHouse = new OlympiadHousesDO("Akkadians", 0,
					0, 0, newDate, null);
			OlympiadHousesDO aryansHouse = new OlympiadHousesDO("Aryans", 0, 0, 0,
					newDate, null);
			OlympiadHousesDO mouryasHouse = new OlympiadHousesDO("Mouryas", 0, 0,
					0, newDate, null);
			SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
			Session session = sessionFactory.openSession();
			Transaction transaction = session.beginTransaction();
			Query checkDataExists = session.createQuery("FROM OlympiadHousesDO");
			List<EmployeeInformationVO> list = checkDataExists.list();

			if (list.isEmpty()) {
				session.save(spartanHouse);
				session.save(suryavanshHouse);
				session.save(aztechsHouse);
				session.save(akkadiansHouse);
				session.save(aryansHouse);
				session.save(mouryasHouse);
			} else {
				System.out.println("Records are already exists.");
			}
			transaction.commit();
		} catch (ParseException exception) {
			exception.printStackTrace();
			System.err.println("Parse Exception ::::in checkOlympiadHouseInfo()"
					+ exception.getMessage());
		} catch (NullPointerException nullpointerException) {
			nullpointerException.printStackTrace();
			System.err.println("Null pointer exception in checkOlympiadHouseInfo()"
					+ nullpointerException.getMessage());
		}
	}

	/** 
	 * This method is used to update the COUNT of employees  in HOUSES_OVERVIEW.
	 * @param coreHr,house_Name
	 * @return success
	 * 
	 */
	public String updateCount(CoreHrDO coreHrEmployee_Info, String house_Name) {
		SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
		Session session = sessionFactory.openSession();
		Transaction transaction = session.beginTransaction();
		try {
			String count_Query = null;
			String grandTotalQuery = null;
			Query totalCountQuery = null;

			Date date = new Date();
			System.err.println("HOUSE_NAME:::::"+house_Name);
			information.setHouseName(house_Name);
			System.err.print(coreHrEmployee_Info.getGender());
			information.setGender(coreHrEmployee_Info.getGender());
			information.setLastUpdatedDate(date);

			String gender = information.getGender();
			Date lastAddedDate = information.getLastUpdatedDate();
			//For getting the COUNT of the employees 
			count_Query = "SELECT COUNT(HOUSE_NAME) FROM EMPLOYEE_INFO WHERE HOUSE_NAME=:HOUSE_NAME AND  GENDER=:GENDER ";
			Query countQuery = session.createSQLQuery(count_Query);
			countQuery.setParameter("HOUSE_NAME", house_Name);
			countQuery.setParameter("GENDER", gender);
			BigInteger convertedValue = (BigInteger) countQuery.uniqueResult();
			int returnValue = convertedValue.intValue();

			// For updating the no of males in each house
			if (gender.equalsIgnoreCase("Male")) {

				String updateQuery = "UPDATE HOUSES_OVERVIEW SET  NO_OF_MALES=:NO_OF_MALES , LAST_UPDATED_DATE=:LAST_UPDATED_DATE WHERE HOUSE_NAME=:HOUSE_NAME";
				Query updateMaleQuery = session.createSQLQuery(updateQuery);
				updateMaleQuery.setParameter("NO_OF_MALES", returnValue);
				updateMaleQuery.setParameter("HOUSE_NAME", house_Name);
				updateMaleQuery.setParameter("LAST_UPDATED_DATE", lastAddedDate);
				updateMaleQuery.executeUpdate();

			} else if (gender.equalsIgnoreCase("Female")) {

				// For updating the no of females in each house
				String updateQuery = "UPDATE HOUSES_OVERVIEW SET  NO_OF_FEMALES=:NO_OF_FEMALES, LAST_UPDATED_DATE=:LAST_UPDATED_DATE WHERE HOUSE_NAME=:HOUSE_NAME";
				Query updateFemaleQuery = session.createSQLQuery(updateQuery);
				updateFemaleQuery.setParameter("NO_OF_FEMALES", returnValue);
				updateFemaleQuery.setParameter("HOUSE_NAME", house_Name);
				updateFemaleQuery
				.setParameter("LAST_UPDATED_DATE", lastAddedDate);
				updateFemaleQuery.executeUpdate();

			} else {

				System.err.println("Something Wrong");

			}

			// for updating the sum of the males and females
			grandTotalQuery = "SELECT (SUM(NO_OF_MALES)+SUM(NO_OF_FEMALES))  FROM HOUSES_OVERVIEW WHERE HOUSE_NAME=:HOUSE_NAME";

			if (!(grandTotalQuery == null)) {

				totalCountQuery = session.createSQLQuery(grandTotalQuery);
				totalCountQuery.setParameter("HOUSE_NAME", house_Name);

			}

			BigDecimal convertedValue1 = (BigDecimal) totalCountQuery.uniqueResult();
			int returnValue1 = convertedValue1.intValue();
			if (!grandTotalQuery.isEmpty()) {

				String updateQuery = "UPDATE HOUSES_OVERVIEW SET  TOTAL=:TOTAL WHERE HOUSE_NAME=:HOUSE_NAME";
				Query updateGrandTotalQuery = session
						.createSQLQuery(updateQuery);
				updateGrandTotalQuery.setParameter("TOTAL", returnValue1);
				updateGrandTotalQuery.setParameter("HOUSE_NAME", house_Name);
				updateGrandTotalQuery.executeUpdate();

			}
		} catch (HibernateException hibernateException) {

			hibernateException.printStackTrace();
			System.err.println(" CoreHrDAOImpl in side  getCountOfEmployeeInfo exception ::::: HibernateException"
					+ hibernateException.getMessage());

		} catch (NullPointerException nullPointerException) {
			nullPointerException.printStackTrace();
			System.err.println(" CoreHrDAOImpl in side  getCountOfEmployeeInfo exception ::::: Nullpointer Exception"
					+ nullPointerException.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
			System.err.println(" CoreHrDAOImpl in side  getCountOfEmployeeInfo exception ::::: Exception"
					+ e.getMessage());
		} finally {
			transaction.commit();
			session.close();
			System.err.println(" CoreHrDAOImpl Inside Finnally method:::::::");
		}
		return "Success";
	}

	/**
	 * This method is used to get the olympiadHouses list of employees 
	 * who are present in that house.
	 */

	@Override
	public List getOlympiadDetails() {
		List houseOverViewList=null;
		try
		{
			SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
			Session session = sessionFactory.openSession();

			Query query = session.createQuery("FROM  OlympiadHousesDO");
			houseOverViewList = query.list();
System.out.println("List is:::;"+houseOverViewList);

		}catch (HibernateException h) {
			h.printStackTrace();
			System.err
			.println(" UserLoginDaoImpl in side  getUserAutheticationData exception ::::: HibernateException"
					+ h.getMessage());
		} catch (NullPointerException nullPointerException) {
			nullPointerException.printStackTrace();
			System.err
			.println(" UserLoginDaoImpl in side  getUserAutheticationData exception ::::: Nullpointer Exception"
					+ nullPointerException.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
			System.err
			.println(" UserLoginDaoImpl in side  getUserAutheticationData exception ::::: Exception"
					+ e.getMessage());
		} finally {


			System.err.println(" CoreHrDAOImpl Inside Finnally method:::::::");
		}
		return houseOverViewList;
	}

	/**
	 * This method is used to serach the employees based on their ID.
	 */
	@Override
	public List searchHouseDetailsById(OlympiadHousesDO olympiadHousesDO) {
		List<Object[]> empByHouseList =null;
		try{
			SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
			Session session = sessionFactory.openSession();
			String house_Name=olympiadHousesDO.getHouseName();
			Query query = session.createQuery("FROM EmployeeInformationDO WHERE  HOUSE_NAME=:HOUSE_NAME");
			query.setParameter("HOUSE_NAME", house_Name);
			empByHouseList = query.list();
		}catch(NullPointerException exception){
			exception.printStackTrace();
		}
		return empByHouseList;

	}

	/**
	 * This method is used to delete the employees based on the ID.
	 */
	@Override
	public void deleteEmployeeInfoById(EmployeeInformationDO informationDO) {
		try {

			SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
			Session session = sessionFactory.openSession();
			Transaction transaction = session.beginTransaction();
			int employeeid = informationDO.getEmpId();
			
			
			
			//For updating the status of the deleted employee
			String updateEmpStatus ="UPDATE MAIN_CORE_HR SET STATUS=:STATUS WHERE EMPLOYEE_ID=:EMPLOYEE_ID";
			Query updateEmpInfo = session.createSQLQuery(updateEmpStatus);
			updateEmpInfo.setParameter("STATUS","EXIT");
			updateEmpInfo.setParameter("EMPLOYEE_ID",employeeid);
			updateEmpInfo.executeUpdate();
			
			//for comparing the data of same ID
			String searchEmpId = " SELECT EMPLOYEE_ID FROM EMPLOYEE_INFO WHERE EMPLOYEE_ID = ?";
			SQLQuery searchEmpIdQuery = session.createSQLQuery(searchEmpId);
			searchEmpIdQuery.setParameter(0, employeeid);
			List emplInfoList = searchEmpIdQuery.list();

			String searchEmpIdInCoreHr = " SELECT EMPLOYEE_ID FROM EMPLOYEE_INFO WHERE EMPLOYEE_ID = ?";
			Query searchEmpIdInCoreHrQuery = session.createSQLQuery(searchEmpIdInCoreHr);
			searchEmpIdInCoreHrQuery.setParameter(0, employeeid);
			List coreHrList = searchEmpIdInCoreHrQuery.list();

			
			if (emplInfoList.equals(coreHrList)) {
				
				/*String insertRecrdById ="INSERT INTO TRANSACTIONS (ID,EMPLOYEE_ID,EMPLOYEE_NAME,EMAIL,GENDER,HOUSE_NAME,DESIGNATION,MOBILE,PROJECT,LOC,DOJ,DOE)"
										+"SELECT (SELECT (COALESCE(MAX(ID),0)+1) FROM TRANSACTIONS) ID,hr.EMPLOYEE_ID, hr.EMPLOYEE_NAME,hr.EMAIL,hr.GENDER"
										+",(SELECT empinfo1.HOUSE_NAME FROM EMPLOYEE_INFO empinfo1 WHERE empinfo1.EMPLOYEE_ID=?), hr.DESIGNATION, hr.MOBILE"
										+",hr.PROJECT, hr.LOC, hr.DOJ, CURDATE() FROM coreHr hr WHERE hr.EMPLOYEE_ID=?";*/
				
				String insertRecrdById ="INSERT INTO TRANSACTIONS (ID,EMPLOYEE_ID,EMPLOYEE_NAME,EMAIL,GENDER,HOUSE_NAME,DESIGNATION,MOBILE,PROJECT,LOC,DOE)"
										+"SELECT (SELECT (COALESCE(MAX(ID),0)+1) FROM TRANSACTIONS) ID,hr.EMPLOYEE_ID, hr.EMPLOYEE_NAME,hr.EMAIL,hr.GENDER"
										+",(SELECT empinfo1.HOUSE_NAME FROM EMPLOYEE_INFO empinfo1 WHERE empinfo1.EMPLOYEE_ID=?), hr.DESIGNATION, hr.MOBILE"
										+",hr.PROJECT, hr.LOC, CURDATE() FROM MAIN_CORE_HR hr WHERE hr.EMPLOYEE_ID=?";

				SQLQuery query = session.createSQLQuery(insertRecrdById);
				query.setParameter(0, employeeid);
				query.setParameter(1, employeeid);
				query.executeUpdate();

				String getIdInfo = "SELECT GENDER,HOUSE_NAME FROM EMPLOYEE_INFO WHERE EMPLOYEE_ID=?";
				SQLQuery genderSearch = session.createSQLQuery(getIdInfo);
				genderSearch.setParameter(0, employeeid);
				List genderList = genderSearch.list();
				Iterator iterator = genderList.iterator();
				Object idInfoObject[] = null;
				idInfoObject = (Object[]) iterator.next();
				String gender = (String) idInfoObject[0];
				String house_Name=(String) idInfoObject[1];

				/*For Deleting Records*/
				String deleteRecrdByIdEmp = "DELETE emp.*, hr.*  FROM EMPLOYEE_INFO emp , MAIN_CORE_HR hr "
											+ "WHERE emp.EMPLOYEE_ID= hr.EMPLOYEE_ID AND emp.EMPLOYEE_ID =?";
				SQLQuery deleteRecrdByIdEMpQuery = session
						.createSQLQuery(deleteRecrdByIdEmp);
				deleteRecrdByIdEMpQuery.setParameter(0, employeeid);
				deleteRecrdByIdEMpQuery.executeUpdate();

				/*For Updating Count*/
				String count_Query = "SELECT COUNT(HOUSE_NAME) FROM EMPLOYEE_INFO WHERE HOUSE_NAME=:HOUSE_NAME AND  GENDER=:GENDER ";
				Query countQuery = session.createSQLQuery(count_Query);
				countQuery.setParameter("HOUSE_NAME", house_Name);
				countQuery.setParameter("GENDER", gender);
				BigInteger convertedValue = (BigInteger) countQuery.uniqueResult();
				int returnValue = convertedValue.intValue();

				// For updating the no of males in each house
				if (gender.equalsIgnoreCase("Male")) {

					String updateQuery = "UPDATE HOUSES_OVERVIEW SET  NO_OF_MALES=:NO_OF_MALES WHERE HOUSE_NAME=:HOUSE_NAME";
					Query updateMaleQuery = session.createSQLQuery(updateQuery);
					updateMaleQuery.setParameter("NO_OF_MALES", returnValue);
					updateMaleQuery.setParameter("HOUSE_NAME", house_Name);
					updateMaleQuery.executeUpdate();

				} else if (gender.equalsIgnoreCase("Female")) {

					// For updating the no of females in each house

					String updateQuery = "UPDATE HOUSES_OVERVIEW SET NO_OF_FEMALES=:NO_OF_FEMALES WHERE HOUSE_NAME=:HOUSE_NAME";
					Query updateFemaleQuery = session.createSQLQuery(updateQuery);
					updateFemaleQuery.setParameter("NO_OF_FEMALES", returnValue);
					updateFemaleQuery.setParameter("HOUSE_NAME", house_Name);
					updateFemaleQuery.executeUpdate();

				} else {

					System.err.println("Something Wrong");

				}
				Query totalCountQuery = null;
				/*For Updating Grand Total*/
				String grandTotalQuery = "SELECT (SUM(NO_OF_MALES)+SUM(NO_OF_FEMALES)) FROM HOUSES_OVERVIEW WHERE HOUSE_NAME=:HOUSE_NAME";

				if (!(grandTotalQuery == null)) {

					totalCountQuery = session.createSQLQuery(grandTotalQuery);
					totalCountQuery.setParameter("HOUSE_NAME", house_Name);

				}

				BigDecimal convertedValue1 = (BigDecimal) totalCountQuery.uniqueResult();
				int returnValue1 = convertedValue1.intValue();
				if (!grandTotalQuery.isEmpty()) {

					String updateQuery = "UPDATE HOUSES_OVERVIEW SET  TOTAL=:TOTAL WHERE HOUSE_NAME=:HOUSE_NAME";
					Query updateGrandTotalQuery = session.createSQLQuery(updateQuery);
					updateGrandTotalQuery.setParameter("TOTAL", returnValue1);
					updateGrandTotalQuery.setParameter("HOUSE_NAME", house_Name);
					updateGrandTotalQuery.executeUpdate();

				}
				transaction.commit();
			}
		} catch (HibernateException hibernateException) {
			hibernateException.printStackTrace();
			System.err
			.println("HibernateException in deleteEmployeeInfoById :::::"
					+ hibernateException.getMessage());
		} catch (NullPointerException nullPointerException) {
			nullPointerException.printStackTrace();
			System.err
			.println("Null pointer Exception in deleteEmployeeInfoById:::::"
					+ nullPointerException.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
			System.err.println("Exception in deleteEmployeeInfoById"
					+ e.getMessage());
		}

	}

	/**
	 * This method is used to fetch the all the employees information 
	 * in the EMPLOYEE_INFO table.
	 * 
	 */
	@Override
	public List getEmployeesDetails() {
		List<EmployeeInformationDO> employeesList = null;
		try {
			SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
			Session session = sessionFactory.openSession();
			Query emlployesQuery = session.createQuery("FROM EmployeeInformationDO");
			employeesList = emlployesQuery.list();
		} catch (NullPointerException nullPointerException) {
			nullPointerException.printStackTrace();
		} catch (HibernateException hibernateException) {
			hibernateException.printStackTrace();
		} catch (Exception exception) {
			exception.printStackTrace();
		}
		return employeesList;
	}

	/**
	 * This method is used to get the transactions happed on the tables 
	 * in the olympiad tables.
	 */
	@Override
	public List<TransactionDetailsDO> getOlympiadTransactions() {
		List<TransactionDetailsDO> transactionsList = null;
		try {
			SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
			Session session = sessionFactory.openSession();
			Query emlployesQuery = session.createSQLQuery("SELECT * FROM TRANSACTIONS");
			transactionsList = emlployesQuery.list();
			System.out.println("TransactionsList::::"+transactionsList);
		} catch (NullPointerException nullPointerException) {
			nullPointerException.printStackTrace();
		} catch (HibernateException hibernateException) {
			hibernateException.printStackTrace();
		} catch (Exception exception) {
			exception.printStackTrace();
		}
		return transactionsList;
	}

	
	//For getting the Count
	public List getActiveEmployeesDetails(){
		List activeEmployeeList = null;
		try{
			
		SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
		Session session = sessionFactory.openSession();
		
		String getIdInfo = "SELECT * FROM MAIN_CORE_HR WHERE  STATUS ='Active' AND HOUSE_ALLOCATED_STATUS='N'";
		SQLQuery genderSearch = session.createSQLQuery(getIdInfo);
		activeEmployeeList = genderSearch.list();
		getEmployeesStatus();
		}catch(NullPointerException nullPointerException){
			nullPointerException.printStackTrace();
		}catch (HibernateException hibernateException) {
			hibernateException.printStackTrace();
		}catch (Exception exception) {
			exception.printStackTrace();
		}
		return activeEmployeeList;
	}
	
	
	/**
	 * This method fetches the employees who are not assigned to the houses.
	 * @return empStatus
	 */
	@Override
	public int getEmployeesStatus(){
		List activeEmployeeList = null;
		int empStatus = 0;
		try{
			
		SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
		Session session = sessionFactory.openSession();
		
		String getIdInfo = "SELECT EMPLOYEE_ID, EMPLOYEE_NAME, GENDER,STATUS FROM MAIN_CORE_HR WHERE  STATUS ='Active' AND HOUSE_ALLOCATED_STATUS='N'";
		SQLQuery genderSearch = session.createSQLQuery(getIdInfo);
		activeEmployeeList = genderSearch.list();
		getCountOfHouses(activeEmployeeList);
		empStatus = getCountOfHouses(activeEmployeeList);
		
		}catch(NullPointerException nullPointerException){
			nullPointerException.printStackTrace();
		}catch (HibernateException hibernateException) {
			hibernateException.printStackTrace();
		}catch (Exception exception) {
			exception.printStackTrace();
		}
		return empStatus;
	}
	
	
	/**
	 * This method uses to get the overview of the olympiad Houses.
	 * @param activeEmployeeList
	 * @return status
	 */
	public int getCountOfHouses(List activeEmployeeList){
		int status=0;
		try{
			checkOlympiadHouseInfo();
		System.out.println("Inside Get CountOfHOuses");
		SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
		Session session = sessionFactory.openSession();
		
		System.err.println("list:::"+activeEmployeeList);
		Object countObj[]=null;
		String gender = null;
		if(!activeEmployeeList.isEmpty()){
		Iterator itr = activeEmployeeList.iterator();
		
		while (itr.hasNext()) {
			countObj = (Object[]) itr.next();
			System.err.println("Employee Info who are in Active:::"+countObj[0]+"----"+countObj[1]+"---"+countObj[2]+"----"+countObj[3]);
			break;
		}
		gender = (String) countObj[2];
		}
		
		
		if(!(gender==null)){
		
		if(gender.equalsIgnoreCase("Male")){

			Iterator iterator=null;
			String maleMinCount = "SELECT HOUSE_NAME,NO_OF_MALES FROM HOUSES_OVERVIEW WHERE NO_OF_MALES=(SELECT MIN(NO_OF_MALES) FROM HOUSES_OVERVIEW)";
			Query query = session.createSQLQuery(maleMinCount)
					.addScalar("HOUSE_NAME", Hibernate.STRING)
					.addScalar("NO_OF_MALES", Hibernate.INTEGER);
			List listOfMales = query.list();
			iterator = listOfMales.iterator();

			Object maleCountObj[] = null;		
			while (iterator.hasNext()) {
				maleCountObj = (Object[]) iterator.next();
				System.out.println("House Details are ::::"+countObj[0]+"-----"+countObj[1]);
				break;
			}
			System.err.println("Length is::::::::::"+countObj.length);

			//If the object having only one house
			if (maleCountObj.length == 1) {
				System.err.println("Inside object length = 1");
				String house_Name = (String) countObj[0];
				status = assignHouse(activeEmployeeList,house_Name);
			}else{

				Object minDateObjectMale[] = null;
				String minDateMale = " SELECT HOUSE_NAME,NO_OF_MALES,LAST_UPDATED_DATE FROM  HOUSES_OVERVIEW ORDER BY  NO_OF_MALES,LAST_UPDATED_DATE LIMIT 1";
				Query minDateQueryForMale = session
						.createSQLQuery(minDateMale)
						.addScalar("HOUSE_NAME", Hibernate.STRING)
						.addScalar("LAST_UPDATED_DATE", Hibernate.DATE);
				List minDatesList = minDateQueryForMale.list();
				Iterator minDateIterator = minDatesList.iterator();
				while (minDateIterator.hasNext()) {
					minDateObjectMale = (Object[]) minDateIterator.next();
					System.err.println(minDateObjectMale[0] + "---Male-----" + minDateObjectMale[1]);
				}
				System.out.println("Length of the Date is ::::"+minDateObjectMale.length);
				if (minDateObjectMale.length == 2) {

					String house_Name = (String) minDateObjectMale[0];
					System.out.println("House Name is :::"+house_Name);
					status =  assignHouse(activeEmployeeList,house_Name);

				} else {

					String house_Name = null;
					getHouseIdOfHouses(activeEmployeeList,house_Name);

				}


			}
		}else{
			
			if(gender.equalsIgnoreCase("Female")){
				
				System.out.println("Inside the else in female");
			Iterator iterator=null;
			String maleMinCount = "SELECT HOUSE_NAME,NO_OF_FEMALES FROM HOUSES_OVERVIEW WHERE NO_OF_FEMALES=(SELECT MIN(NO_OF_FEMALES) FROM HOUSES_OVERVIEW)";
			Query query = session.createSQLQuery(maleMinCount)
					.addScalar("HOUSE_NAME", Hibernate.STRING)
					.addScalar("NO_OF_FEMALES", Hibernate.INTEGER);
			List listOfMales = query.list();
			iterator = listOfMales.iterator();

			Object maleCountObj[] = null;		
			while (iterator.hasNext()) {
				maleCountObj = (Object[]) iterator.next();
				System.out.println("House Details are ::::"+countObj[0]+"-----"+countObj[1]);
			}

			System.err.println("Length is::::::::::"+countObj.length);

			//If the object having only one house
			
			if (maleCountObj.length == 1) {
				System.err.println("Inside object length = 1");
				String house_Name = (String) countObj[0];
				assignHouse(activeEmployeeList,house_Name);
			}else{

				Object minDateObjectMale[] = null;
				String minDateMale = " SELECT HOUSE_NAME,NO_OF_FEMALES,LAST_UPDATED_DATE FROM  HOUSES_OVERVIEW ORDER BY NO_OF_FEMALES,LAST_UPDATED_DATE LIMIT 1";
				Query minDateQueryForMale = session
						.createSQLQuery(minDateMale)
						.addScalar("HOUSE_NAME", Hibernate.STRING)
						.addScalar("LAST_UPDATED_DATE", Hibernate.DATE);
				List minDatesList = minDateQueryForMale.list();
				Iterator minDateIterator = minDatesList.iterator();
			
				while (minDateIterator.hasNext()) {
					minDateObjectMale = (Object[]) minDateIterator.next();
					System.err.println(minDateObjectMale[0] + "---Female-----" + minDateObjectMale[1]);
				}
				System.out.println("Length of the Date is ::::"+minDateObjectMale.length);
				if (minDateObjectMale.length == 2) {

					String house_Name = (String) minDateObjectMale[0];
					System.out.println("House Name is :::"+house_Name);
					assignHouse(activeEmployeeList,house_Name);

				} else {

					String house_Name = null;
					getHouseIdOfHouses(activeEmployeeList,house_Name);
					

				}


			}
			}
		}
	}
		}catch(NullPointerException nullPointerException){
			nullPointerException.printStackTrace();
		}catch (HibernateException hibernateException) {
			hibernateException.printStackTrace();
		}catch (Exception exception) {
			exception.printStackTrace();
		}
		return status;
		
	}
	
	/**
	 * This method fetches the ID of the respective house if the AST_UPDATED_DATE is EQUAL.
	 * @param activeEmployeeList
	 * @param house_Name
	 * @return houseIdstatus
	 */
	public int getHouseIdOfHouses(List activeEmployeeList,String house_Name) {
		int houseIdstatus =0;
		try{
			SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
			Session session = sessionFactory.openSession();
			

			
			Iterator activeEmpIterator = activeEmployeeList.iterator();
			
			Object actEmpObj[]=null;
			while (activeEmpIterator.hasNext()) {
				actEmpObj = (Object[]) activeEmpIterator.next();
				//System.err.println("Active Employees List::::"+"Id:::"+actEmpObj[0]+"::::Name::"+actEmpObj[1]+":::GENDER::"+actEmpObj[2]+":::Status::"+actEmpObj[3]);
				break;
			}
			String gender = (String) actEmpObj[2];
			if (gender.equalsIgnoreCase("Male")) {

				Object minDateObjectMale[] = null;
				String minDateMale = "SELECT HOUSE_ID,HOUSE_NAME FROM HOUSES_OVERVIEW WHERE NO_OF_MALES=(SELECT MIN(NO_OF_MALES) FROM HOUSES_OVERVIEW) ORDER BY HOUSE_ID LIMIT 1";
				Query minDateQueryForFemale = session.createSQLQuery(minDateMale)
						.addScalar("HOUSE_ID", Hibernate.INTEGER)
						.addScalar("HOUSE_NAME", Hibernate.STRING);
				List minDatesList = minDateQueryForFemale.list();
				Iterator minDateFemaleIterator = minDatesList.iterator();

				minDateObjectMale = (Object[]) minDateFemaleIterator.next();
				house_Name = (String) minDateObjectMale[1];
				houseIdstatus = assignHouse(activeEmployeeList, house_Name);

			} else if (gender.equalsIgnoreCase("Female")) {

				String minDateMale = "SELECT HOUSE_ID,HOUSE_NAME FROM HOUSES_OVERVIEW WHERE NO_OF_FEMALES=(SELECT MIN(NO_OF_FEMALES) FROM HOUSES_OVERVIEW) ORDER BY HOUSE_ID LIMIT 1";
				Query minDateQueryForFemale = session.createSQLQuery(minDateMale)
						.addScalar("HOUSE_ID", Hibernate.INTEGER)
						.addScalar("HOUSE_NAME", Hibernate.STRING);
				List minDatesList = minDateQueryForFemale.list();
				Iterator minDateFemaleIterator = minDatesList.iterator();
				Object minDateObjectFemale[] = null;
				minDateObjectFemale = (Object[]) minDateFemaleIterator.next();
				house_Name = (String) minDateObjectFemale[1];
				houseIdstatus = assignHouse(activeEmployeeList, house_Name);
			}
		}catch(NullPointerException nullPointerException){
			nullPointerException.printStackTrace();
		}catch (HibernateException hibernateException) {
			hibernateException.printStackTrace();
		}catch (Exception exception) {
			exception.printStackTrace();
		}
		return houseIdstatus;
	}
	
	
	
	/**
	 * This method Assigns the House for the employee based on the count of the 
	 * NO_OF_MALES, NO_OF_FEMALES.
	 * @param activeEmployeeList
	 * @param house_Name
	 * @return assignHouseStatus
	 */
	public int assignHouse(List activeEmployeeList,String house_Name){
		int assignHouseStatus=0;
		try{
			
			System.err.println("Inside the Assign House()");
			SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
			Session session = sessionFactory.openSession();
			Transaction transaction = session.beginTransaction();
			
			Iterator activeEmpIterator = activeEmployeeList.iterator();
			Object actEmpObj[]=null;
			while (activeEmpIterator.hasNext()) {
				actEmpObj = (Object[]) activeEmpIterator.next();
			break;
			}
			if(!(actEmpObj==null)){
			//setting the values for Active Employees 
			HrMain hrMain =new HrMain();
			hrMain.setEmpNo((int) actEmpObj[0]);
			hrMain.setEmpName((String) actEmpObj[1]);
			hrMain.setGender((String) actEmpObj[2]);
				
			//Assigning the house for the employee
			EmployeeInformationDO employeeInformation = new EmployeeInformationDO();
			
			employeeInformation.setEmpId(hrMain.getEmpNo());
			employeeInformation.setEmpName(hrMain.getEmpName());
			employeeInformation.setHouseName(house_Name);
			employeeInformation.setGender(hrMain.getGender());
			employeeInformation.setHouseAllocatedDate(new Date());
			employeeInformation.setLastUpdatedDate(new Date());
			
			assignHouseStatus = (Integer)session.save(employeeInformation);
			transaction.commit();
			updateCountOfHouses(activeEmployeeList, house_Name);
			session.close();
			System.out.println("Employee Information have been Commited");
			}else{
				System.err.println("No Employees are there to alloctae");
			}
		}catch(NullPointerException nullPointerException){
			nullPointerException.printStackTrace();
		}catch (HibernateException hibernateException) {
			hibernateException.printStackTrace();
		}catch (Exception exception) {
			exception.printStackTrace();
		}
		return assignHouseStatus;
	}
	
	/**
	 * This method updates the count of the Houses When the employee has been added.
	 * @param activeEmployeeList
	 * @param house_Name
	 * @return updateCountStatus
	 */
	
	public int updateCountOfHouses(List activeEmployeeList,String house_Name){
		int updateCountStatus=0;
		try{
			System.err.println("Inside Update Count");
			SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
			Session session = sessionFactory.openSession();
			Transaction transaction = session.beginTransaction();
			
			
			String count_Query = null;
			String grandTotalQuery = null;
			Query totalCountQuery = null;

			
			Iterator activeEmpIterator = activeEmployeeList.iterator();
			
			Object actEmpObj[]=null;
			while (activeEmpIterator.hasNext()) {
				actEmpObj = (Object[]) activeEmpIterator.next();
				//System.err.println("Active Employees List::::"+"Id:::"+actEmpObj[0]+"::::Name::"+actEmpObj[1]+":::GENDER::"+actEmpObj[2]+":::Status::"+actEmpObj[3]);
				break;
			}
			
			
			//setting the values for Active Employees 
			HrMain hrMain =new HrMain();
			hrMain.setEmpNo((int) actEmpObj[0]);
			hrMain.setEmpName((String) actEmpObj[1]);
			hrMain.setGender((String) actEmpObj[2]);
			
			System.out.println("Setting values for informationDO");
			Date date = new Date();
			System.err.println("HOUSE_NAME:::::"+house_Name);
			information.setHouseName(house_Name);
			System.err.print(hrMain.getGender());
			information.setGender(hrMain.getGender());
			information.setLastUpdatedDate(date);

			String gender = information.getGender();
			Date lastAddedDate = information.getLastUpdatedDate();
			//For getting the COUNT of the employees 
			count_Query = "SELECT COUNT(HOUSE_NAME) FROM EMPLOYEE_INFO WHERE HOUSE_NAME=:HOUSE_NAME AND  GENDER=:GENDER ";
			Query countQuery = session.createSQLQuery(count_Query);
			countQuery.setParameter("HOUSE_NAME", house_Name);
			countQuery.setParameter("GENDER", gender);
			BigInteger convertedValue = (BigInteger) countQuery.uniqueResult();
			int returnValue = convertedValue.intValue();
			
			System.err.println("Return Value is:::"+returnValue);

			// For updating the no of males in each house
			
			if (gender.equalsIgnoreCase("Male")) {
				
				System.err.println("Inside Male ");
				System.err.println("HOUSE_NAME"+house_Name);
				String updateQuery = "UPDATE HOUSES_OVERVIEW SET  NO_OF_MALES=:NO_OF_MALES , LAST_UPDATED_DATE=:LAST_UPDATED_DATE WHERE HOUSE_NAME=:HOUSE_NAME";
				Query updateMaleQuery = session.createSQLQuery(updateQuery);
				updateMaleQuery.setParameter("NO_OF_MALES", returnValue);
				updateMaleQuery.setParameter("HOUSE_NAME", house_Name);
				updateMaleQuery.setParameter("LAST_UPDATED_DATE", lastAddedDate);
				updateCountStatus = updateMaleQuery.executeUpdate();
				
			} else if (gender.equalsIgnoreCase("Female")) {
				
				// For updating the no of females in each house
				String updateQuery = "UPDATE HOUSES_OVERVIEW SET  NO_OF_FEMALES=:NO_OF_FEMALES, LAST_UPDATED_DATE=:LAST_UPDATED_DATE WHERE HOUSE_NAME=:HOUSE_NAME";
				Query updateFemaleQuery = session.createSQLQuery(updateQuery);
				updateFemaleQuery.setParameter("NO_OF_FEMALES", returnValue);
				updateFemaleQuery.setParameter("HOUSE_NAME", house_Name);
				updateFemaleQuery.setParameter("LAST_UPDATED_DATE", lastAddedDate);
				updateCountStatus = updateFemaleQuery.executeUpdate();

			} else {

				System.err.println("Something Wrong");

			}
			
			grandTotalQuery = "SELECT (SUM(NO_OF_MALES)+SUM(NO_OF_FEMALES))  FROM HOUSES_OVERVIEW WHERE HOUSE_NAME=:HOUSE_NAME";

			if (!(grandTotalQuery == null)) {

				totalCountQuery = session.createSQLQuery(grandTotalQuery);
				totalCountQuery.setParameter("HOUSE_NAME", house_Name);

			}

			BigDecimal convertedValue1 = (BigDecimal) totalCountQuery.uniqueResult();
			int returnValue1 = convertedValue1.intValue();
			if (!grandTotalQuery.isEmpty()) {

				String updateQuery = "UPDATE HOUSES_OVERVIEW SET  TOTAL=:TOTAL WHERE HOUSE_NAME=:HOUSE_NAME";
				Query updateGrandTotalQuery = session
						.createSQLQuery(updateQuery);
				updateGrandTotalQuery.setParameter("TOTAL", returnValue1);
				updateGrandTotalQuery.setParameter("HOUSE_NAME", house_Name);
				updateCountStatus = updateGrandTotalQuery.executeUpdate();

			}
			
			
			String updateQuery = "UPDATE MAIN_CORE_HR SET HOUSE_ALLOCATED_STATUS='Y' WHERE EMPLOYEE_ID=?";
			Query updateFemaleQuery = session.createSQLQuery(updateQuery);
			updateFemaleQuery.setParameter(0, actEmpObj[0]);
			updateCountStatus = updateFemaleQuery.executeUpdate();
			
			transaction.commit();
			getEmployeesStatus();
			System.out.println("Status has been updated");
			
		}catch(NullPointerException nullPointerException){
			nullPointerException.printStackTrace();
		}catch (HibernateException hibernateException) {
			hibernateException.printStackTrace();
		}catch (Exception exception) {
			exception.printStackTrace();
		}
		return updateCountStatus;
	}

	/**
	 * This Method Fetches the EmployeeInformation based on EMPLOYEE_ID ..
	 * @param emp_info
	 * @return empByIdList
	 */
	@Override
	public List searchEmpDetailsById(EmployeeInformationDO emp_info) {
		List empByIdList =null;
		try {
			SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
			Session session = sessionFactory.openSession();
			int empId=emp_info.getEmpId();
			Query query = session.createQuery("FROM EmployeeInformationDO WHERE  EMPLOYEE_ID=:EMPLOYEE_ID");
			query.setParameter("EMPLOYEE_ID", empId);
			empByIdList = query.list();
			System.out.println("list contains::::"+empByIdList.get(0));
		} catch (NullPointerException nullPointerException) {
			nullPointerException.printStackTrace();
		} catch (HibernateException hibernateException) {
			hibernateException.printStackTrace();
		} catch (Exception exception) {
			exception.printStackTrace();
		}
		return empByIdList;
	}

	/**
	 * This method updates the emloyee HOUSE_NAME,LAST_UPDATED_DATE based on the EMPLOYEE_ID
	 * @param update_Emp_info
	 * @return update_Emp_info_List
	 */
	@Override
	public List updateEmpDetailsById(EmployeeInformationDO update_Emp_info) {
		List update_Emp_info_List =null;
		try {
			SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
			Session session = sessionFactory.openSession();
			Transaction transaction = session.beginTransaction();
			int empId=update_Emp_info.getEmpId();
			String house_Name = update_Emp_info.getHouseName();
			String updateEmpHouse ="UPDATE EMPLOYEE_INFO SET HOUSE_NAME=:HOUSE_NAME ,LAST_UPDATED_DATE=:LAST_UPDATED_DATE WHERE EMPLOYEE_ID=:EMPLOYEE_ID";
			Query updateEmpInfo = session.createSQLQuery(updateEmpHouse);
			updateEmpInfo.setParameter("HOUSE_NAME",house_Name);
			updateEmpInfo.setParameter("EMPLOYEE_ID",empId);
			updateEmpInfo.setParameter("LAST_UPDATED_DATE",new Date());
			updateEmpInfo.executeUpdate();
			transaction.commit();
			UpdateHouseCount();
			
			Query query = session.createQuery("FROM EmployeeInformationDO WHERE  EMPLOYEE_ID=:EMPLOYEE_ID");
			query.setParameter("EMPLOYEE_ID", empId);
			update_Emp_info_List = query.list();
			
		} catch (NullPointerException nullPointerException) {
			nullPointerException.printStackTrace();
		} catch (HibernateException hibernateException) {
			hibernateException.printStackTrace();
		} catch (Exception exception) {
			exception.printStackTrace();
		}
		return update_Emp_info_List;
	}
	
	/**
	 * This method is used to get the count of the Houses from 
	 * EMPLOYEE_INFO table.
	 * Fetches the NO_OF_MALES,NO_OF_FEMALES,TOTAL count of Houses.
	 */
	
	private void UpdateHouseCount(){
	try{
		SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
		Session session = sessionFactory.openSession();
		Transaction transaction = session.beginTransaction();
		
		//Get and UPDATE the COUNT of males 
		String count_Query_Male = "SELECT HOUSE_NAME, COUNT(GENDER) ,GENDER FROM EMPLOYEE_INFO WHERE HOUSE_NAME in "
								+ "('spartans','Aryans','Suryavansh','Aztechs','Akkadians','Mouryas') AND  GENDER='Male' group by HOUSE_NAME "
								+ "order By HOUSE_NAME asc";
		Query countQueryMale = session.createSQLQuery(count_Query_Male);
		List maleCountList = (List) countQueryMale.list();
		Iterator maleCountListIterator = maleCountList.iterator();
		Object maleCountObj[]=null;
		Query updateMaleQuery = null;
		String updatemaleCount = "UPDATE HOUSES_OVERVIEW SET  NO_OF_MALES=?, LAST_UPDATED_DATE=? WHERE HOUSE_NAME =?  order By HOUSE_NAME asc";
		while (maleCountListIterator.hasNext()) {
			maleCountObj = (Object[]) maleCountListIterator.next();
			System.out.println("List Contains:::::"+maleCountObj[0]+"----"+maleCountObj[1]);
			updateMaleQuery = session.createSQLQuery(updatemaleCount);
			updateMaleQuery.setParameter(0, maleCountObj[1]);
			updateMaleQuery.setParameter(1, new Date());
			updateMaleQuery.setParameter(2,  maleCountObj[0]);
			updateMaleQuery.executeUpdate();
			System.out.println("Query updated for "+maleCountObj[0]+"----"+maleCountObj[1]);
			
		}
		//transaction.commit();
		
		//Get and UPDATE the COUNT of Females 
		String count_Query_Female = "SELECT HOUSE_NAME, COUNT(GENDER) ,GENDER FROM EMPLOYEE_INFO WHERE HOUSE_NAME in "
								+ "('spartans','Aryans','Suryavansh','Aztechs','Akkadians','Mouryas') AND  GENDER='Female' group by HOUSE_NAME "
								+ "order By HOUSE_NAME asc";
		Query countQueryFemale = session.createSQLQuery(count_Query_Female);
		List femaleCountList = (List) countQueryFemale.list();
		Iterator femaleCountListIterator = femaleCountList.iterator();
		Object femaleCountObj[]=null;
		Query updateFemaleQuery = null;
		String updateFemaleCount = "UPDATE HOUSES_OVERVIEW SET  NO_OF_FEMALES=?, LAST_UPDATED_DATE=? WHERE HOUSE_NAME =?  order By HOUSE_NAME asc";
		
		while (femaleCountListIterator.hasNext()) {
			femaleCountObj = (Object[]) femaleCountListIterator.next();
			System.out.println("List Contains:::::"+femaleCountObj[0]+"----"+femaleCountObj[1]);
			updateFemaleQuery = session.createSQLQuery(updateFemaleCount);
			updateFemaleQuery.setParameter(0, femaleCountObj[1]);
			updateFemaleQuery.setParameter(1, new Date());
			updateFemaleQuery.setParameter(2,  femaleCountObj[0]);
			updateFemaleQuery.executeUpdate();
			System.out.println("Query updated for "+femaleCountObj[0]+"----"+femaleCountObj[1]);
		}
		//For updating the grand total 
		
		/*String getHousesCount = "SELECT HOUSE_NAME,(SUM(NO_OF_MALES)+SUM(NO_OF_FEMALES))  FROM HOUSES_OVERVIEW WHERE HOUSE_NAME in "
				+ "('spartans','Aryans','Suryavansh','Aztechs','Akkadians','Mouryas')  group By HOUSE_NAME ORDER BY HOUSE_NAME";
		Query houseListQuery = session.createSQLQuery(getHousesCount);
		List housesCountList = houseListQuery.list();
		Iterator houseCountIterator = housesCountList.iterator();
		
		String updateTotalQuery = "Update HOUSES_OVERVIEW SET TOTAL=?";
		
		//Object houseListObject[] = null;
		Query updateSumQuery = null;
		while (houseCountIterator.hasNext()) {
			BigDecimal value = (BigDecimal) houseCountIterator.next();
			
			System.out.println("House object List Contains ::::"+value);
			updateSumQuery = session.createSQLQuery(updateTotalQuery);
			updateSumQuery.setParameter(0, value);
			updateSumQuery.executeUpdate();
		}*/
		transaction.commit();
		
	} catch (NullPointerException nullPointerException) {
		nullPointerException.printStackTrace();
	} catch (HibernateException hibernateException) {
		hibernateException.printStackTrace();
	} catch (Exception exception) {
		exception.printStackTrace();
	}
	}


	/**
	 * This method adds the new houses to the olympiad Tabale.
	 * @param olympiadHousesDO
	 * @return 
	 */
	@Override
	public int coreHrDAO(OlympiadHousesDO olympiadHousesDO) {
		int status=0;
		try{
			SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
			Session session = sessionFactory.openSession();
			Transaction transaction = session.beginTransaction();
			
			String house_Name = olympiadHousesDO.getHouseName();
			olympiadHousesDO.setNoOfFemales(0);
			olympiadHousesDO.setNoOfFemales(0);
			olympiadHousesDO.setGrandTotal(0);
			olympiadHousesDO.setHouseCreationDate(new Date());
			olympiadHousesDO.setLastUpdatedDate(new Date());
			
			status=(Integer) session.save(olympiadHousesDO);
			transaction.commit();
			
		} catch (NullPointerException nullPointerException) {
			nullPointerException.printStackTrace();
		} catch (HibernateException hibernateException) {
			hibernateException.printStackTrace();
		} catch (Exception exception) {
			exception.printStackTrace();
		}
		return status;
	}
	
	
		
}
