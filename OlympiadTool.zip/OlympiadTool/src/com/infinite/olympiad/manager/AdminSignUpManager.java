package com.infinite.olympiad.manager;

import com.infinite.olympiad.DO.AdminSignUpDO;
import com.infinite.olympiad.dao.AdminSignUpDAO;
import com.infinite.olympiad.daoImpl.AdminSignUPDAOImpl;

public class AdminSignUpManager {

	AdminSignUpDAO adminSignUpDAO = new AdminSignUPDAOImpl();

	/**
	 * This method is used to register the user
	 * @param adminSignUpDO
	 * @return returnValue
	 */
	public int registerAdmin(AdminSignUpDO adminSignUpDO) {

		int returnValue=adminSignUpDAO.registerAdmin(adminSignUpDO);

		return returnValue;

	}
}
