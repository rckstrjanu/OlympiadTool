package com.infinite.olympiad.manager;

import java.util.List;

import com.infinite.olympiad.DO.LoginUserDO;
import com.infinite.olympiad.dao.UserLoginDAO;
import com.infinite.olympiad.daoImpl.UserLoginDaoImpl;

public class UserLoginManager {

	private UserLoginDAO loginDao=new UserLoginDaoImpl();

	/**
	 * This method is used to provide the authentication to user.
	 * @param loginUserDO
	 * @return loginDetailsList
	 */
	public List userAutheticationCheck(LoginUserDO loginUserDO) {
		
		List loginDetailsList=loginDao.userAutheticationCheckData(loginUserDO);
		return loginDetailsList;
		
	}


}
