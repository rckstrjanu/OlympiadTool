package com.infinite.olympiad.manager;

import java.util.List;

import com.infinite.olympiad.DO.CoreHrDO;
import com.infinite.olympiad.DO.EmployeeInformationDO;
import com.infinite.olympiad.DO.OlympiadHousesDO;
import com.infinite.olympiad.DO.TransactionDetailsDO;
import com.infinite.olympiad.dao.CoreHrDAO;
import com.infinite.olympiad.daoImpl.CoreHrDAOImpl;

public class CoreHrManager {

	private CoreHrDAO coreHrDAO = new CoreHrDAOImpl();

	/**
	 * This method is used to save the employee information 
	 * @param coreHrEmployee_Info
	 * @return returnValue
	 */
	public int getCoreHrDetails(CoreHrDO coreHrEmployee_Info) {

		int returnValue=coreHrDAO.addCoreHrInfo(coreHrEmployee_Info);

		return returnValue;

	}


	/**
	 * This method is used to get the olympiadHouses information
	 * @return houseOverViewList
	 */
	public List getOlympiadDetails(){

		List houseOverViewList=coreHrDAO.getOlympiadDetails();

		return houseOverViewList;

	}


	/**
	 * This method is used to search the employee by ID.
	 * @param olympiadHousesDO
	 * @return houseEnployeesList
	 */
	public List searchHouseDetailsById(OlympiadHousesDO olympiadHousesDO) {

		List houseEnployeesList = coreHrDAO.searchHouseDetailsById(olympiadHousesDO);

		return houseEnployeesList;
	}


	/**
	 * This method is used to delete the employee by ID.
	 * @param informationDO
	 */
	public void deleteEmployeeInfoById(EmployeeInformationDO informationDO) {

		coreHrDAO.deleteEmployeeInfoById(informationDO);
	}


	/**
	 * This method is used to get the employees details assigned to houses.
	 * @return employeesList
	 */ 
	public List getEmployeesDetails() {

		List employeesList = coreHrDAO.getEmployeesDetails();
		return employeesList;

	}


	/**
	 * This method is used to get the transaction happened on the tables.
	 * @return transactionsList
	 */
	public List<TransactionDetailsDO> getOlympiadTransactions() {

		List<TransactionDetailsDO> transactionsList = coreHrDAO.getOlympiadTransactions();

		return transactionsList;
	}


	public List getActiveEmployeesDetails() {
		
		List actEmpList = coreHrDAO.getActiveEmployeesDetails();
		
		return actEmpList;
	}


	public int getEmployeesStatus() {
		int empStatus = coreHrDAO.getEmployeesStatus();
		return empStatus;
	}


	public List<EmployeeInformationDO> searchEmpDetailsById(EmployeeInformationDO emp_info) {
		List empInfoList = coreHrDAO.searchEmpDetailsById(emp_info);
		return empInfoList;
	}


	public List<EmployeeInformationDO> updateEmpDetailsById(EmployeeInformationDO update_Emp_info) {
		List update_Emp_info_List = coreHrDAO.updateEmpDetailsById(update_Emp_info);
		return update_Emp_info_List;
	}

	public int addNewHouse(OlympiadHousesDO olympiadHousesDO) {
		int status = coreHrDAO.coreHrDAO(olympiadHousesDO);
		return status;
	}
}
