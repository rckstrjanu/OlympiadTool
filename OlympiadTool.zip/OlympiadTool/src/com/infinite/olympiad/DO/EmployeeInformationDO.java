package com.infinite.olympiad.DO;

import java.util.Date;

public class EmployeeInformationDO {

	private int id;
	private int empId;
	private String empName;
	private String houseName;
	private Date houseAllocatedDate;
	private Date lastUpdatedDate;
	private String gender;
	
	//Setters and Getters
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public String getHouseName() {
		return houseName;
	}
	public void setHouseName(String houseName) {
		this.houseName = houseName;
	}
	public Date getHouseAllocatedDate() {
		return houseAllocatedDate;
	}
	public void setHouseAllocatedDate(Date houseAllocatedDate) {
		this.houseAllocatedDate = houseAllocatedDate;
	}
	
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public Date getLastUpdatedDate() {
		return lastUpdatedDate;
	}
	
	public void setLastUpdatedDate(Date lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}
	
	@Override
	public String toString() {
		return "EmployeeInformation [empId=" + empId + ", empName=" + empName
				+ ", houseName=" + houseName + ", houseAllocatedDate="
				+ houseAllocatedDate + ", lastUpdatedDate=" + lastUpdatedDate
				+ ", gender=" + gender + "]";
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
}
