package com.infinite.olympiad.DO;

import java.util.Date;

public class CoreHrDO {

	private int id;
	private int employeeId;
	private String employee_Name;
	private String gender;
	private long mobileNo;
	private String projectName;
	private String designation;
	private String location;
	private String email;
	private String repoManager;
	private Date doj;
	private Date doe;
	
	//Setters and getters
	public Date getDoj() {
		return doj;
	}
	public void setDoj(Date doj) {
		this.doj = doj;
	}
	public Date getDoe() {
		return doe;
	}
	public void setDoe(Date doe) {
		this.doe = doe;
	}
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	public String getEmployee_Name() {
		return employee_Name;
	}
	public void setEmployee_Name(String employee_Name) {
		this.employee_Name = employee_Name;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public long getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(long mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getProjectName() {
		return projectName;
	}
	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getRepoManager() {
		return repoManager;
	}
	public void setRepoManager(String repoManager) {
		this.repoManager = repoManager;
	}
	@Override
	public String toString() {
		return "CoreHr [id=" + id + ", employeeId=" + employeeId
				+ ", employee_Name=" + employee_Name + ", gender=" + gender
				+ ", mobileNo=" + mobileNo + ", projectName=" + projectName
				+ ", designation=" + designation + ", location=" + location
				+ ", email=" + email + ", repoManager=" + repoManager
				+ ", doj=" + doj + ", doe=" + doe + "]";
	}
	
	
}
