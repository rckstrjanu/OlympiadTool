package com.infinite.olympiad.DO;

import java.util.Date;

public class OlympiadHousesDO {

	private int houseId;
	private String houseName;
	private int noOfMales;
	private int noOfFemales;
	private int grandTotal;
	private Date houseCreationDate;
	private Date lastUpdatedDate;
	
	//Setters and Getters 
	public OlympiadHousesDO() {
	}
	

	


	public OlympiadHousesDO(String houseName, int noOfMales, int noOfFemales,
			int grandTotal, Date houseCreationDate, Date lastUpdatedDate) {
		super();
		this.houseName = houseName;
		this.noOfMales = noOfMales;
		this.noOfFemales = noOfFemales;
		this.grandTotal = grandTotal;
		this.houseCreationDate = houseCreationDate;
		this.lastUpdatedDate = lastUpdatedDate;
	}





	public int getHouseId() {
		return houseId;
	}
	public void setHouseId(int houseId) {
		this.houseId = houseId;
	}
	public String getHouseName() {
		return houseName;
	}
	public void setHouseName(String houseName) {
		this.houseName = houseName;
	}
	public int getNoOfMales() {
		return noOfMales;
	}
	public void setNoOfMales(int noOfMales) {
		this.noOfMales = noOfMales;
	}
	public int getNoOfFemales() {
		return noOfFemales;
	}
	public void setNoOfFemales(int noOfFemales) {
		this.noOfFemales = noOfFemales;
	}
	public int getGrandTotal() {
		return grandTotal;
	}
	public void setGrandTotal(int grandTotal) {
		this.grandTotal = grandTotal;
	}
	public Date getLastUpdatedDate() {
		return lastUpdatedDate;
	}
	public void setLastUpdatedDate(Date lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}

	public Date getHouseCreationDate() {
		return houseCreationDate;
	}

	public void setHouseCreationDate(Date houseCreationDate) {
		this.houseCreationDate = houseCreationDate;
	}
	

	@Override
	public String toString() {
		return "OlympiadHouses [houseId=" + houseId + ", houseName="
				+ houseName + ", noOfMales=" + noOfMales + ", noOfFemales="
				+ noOfFemales + ", grandTotal=" + grandTotal
				+ ", houseCreationDate=" + houseCreationDate
				+ ", lastUpdatedDate=" + lastUpdatedDate + "]";
	}

}
