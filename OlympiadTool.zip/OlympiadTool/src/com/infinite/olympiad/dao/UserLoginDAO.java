package com.infinite.olympiad.dao;

import java.util.List;

import com.infinite.olympiad.DO.LoginUserDO;

/**
 * Class UserLoginDAOImpl will implements UserLoginDAO
 *
 */
public interface UserLoginDAO {

	/**
	 * This method is used to provide the authentication for user
	 * based on the email and password.
	 * @param loginUserDO
	 * @return list
	 */
	List userAutheticationCheckData(LoginUserDO loginUserDO);

}
