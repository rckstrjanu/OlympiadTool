package com.infinite.olympiad.dao;

import java.util.List;

import com.infinite.olympiad.DO.CoreHrDO;
import com.infinite.olympiad.DO.EmployeeInformationDO;
import com.infinite.olympiad.DO.HrMain;
import com.infinite.olympiad.DO.OlympiadHousesDO;
import com.infinite.olympiad.DO.TransactionDetailsDO;


public interface CoreHrDAO {
	/** 
	 * This method is used to store the employee information in coreHr table.
	 * @param coreHr
	 * @return id
	 * 
	 */
	int addCoreHrInfo(CoreHrDO coreHrEmployee_Info);

	/**
	 * This method is used to get the olympiadHouses overview Count.
	 * @return list
	 * 
	 */
	List getOlympiadDetails();
	

	/**
	 * This method is used to get the employees based on their ID.
	 * @param olympiadHousesDO
	 * @return list
	 */
	List searchHouseDetailsById(OlympiadHousesDO olympiadHousesDO);

	
	/**
	 * This method is used to delete the employee based on their ID.
	 * @param informationDO
	 * 
	 */
	void deleteEmployeeInfoById(EmployeeInformationDO informationDO);

	/**
	 * This method is used to get the all the employee details in olympiad
	 * who are allocated to houses.
	 * @return list
	 * 
	 */
	List getEmployeesDetails();

	/**
	 * 
	 * This method is used to get the transaction happened in the olympiad table.
	 * @return list
	 * 
	 */
	List<TransactionDetailsDO> getOlympiadTransactions();

	List<HrMain> getActiveEmployeesDetails();

	int getEmployeesStatus();

	List searchEmpDetailsById(EmployeeInformationDO emp_info);

	List updateEmpDetailsById(EmployeeInformationDO update_Emp_info);

	int coreHrDAO(OlympiadHousesDO olympiadHousesDO);
	
}
