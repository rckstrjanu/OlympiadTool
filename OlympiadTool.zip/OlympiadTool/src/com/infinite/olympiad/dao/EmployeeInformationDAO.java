package com.infinite.olympiad.dao;

import java.util.List;

import com.infinite.olympiad.vo.EmployeeInformationVO;

/**
 *  Class EmployeeInformationDAOImpl extends EmployeeInformationDAO
 *
 */
public interface EmployeeInformationDAO {

	/**
	 * This method is used to add the employees information into employee_info table.
	 * @param employeeInformation
	 * @return int
	 */
	int addEmployeeInformation(EmployeeInformationVO employeeInformation);

	/**
	 * This method is used to get the employees information who are allocated to 
	 * houses.
	 * @return list
	 */
	List<EmployeeInformationVO> getEmployeesInfo();

	/**
	 * This method is used to get the employees information based on their ID.
	 * @param id
	 * @return employeeInformationVo
	 */
	EmployeeInformationVO getEmployeesInfoById(int id);

	/**
	 * This method is used to update the count of the employees 
	 * based on the Gender and House.
	 * @param employeeInformation
	 * @return String
	 */
	String updateCount(EmployeeInformationVO employeeInformation);

	/**
	 * This method is used to check weather initially houses are exist or not.
	 */
	void checkOlympiadHouseInfo();
}
