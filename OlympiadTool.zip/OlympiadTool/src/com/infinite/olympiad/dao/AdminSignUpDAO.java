package com.infinite.olympiad.dao;

import com.infinite.olympiad.DO.AdminSignUpDO;

/**
 * This class used to register the user.
 * 
 */
public interface AdminSignUpDAO {

	/**
	 * this method is used to register the User.
	 * @param adminSignUpDO
	 * @return int
	 * 
	 */
	int registerAdmin(AdminSignUpDO adminSignUpDO);
}
