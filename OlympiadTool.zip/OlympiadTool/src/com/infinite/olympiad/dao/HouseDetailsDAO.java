package com.infinite.olympiad.dao;

import com.infinite.olympiad.vo.HouseDetailsVO;

public interface HouseDetailsDAO {
int addhouseDetails(HouseDetailsVO houseDetails);

}
